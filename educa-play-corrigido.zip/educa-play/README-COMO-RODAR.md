# EDUCA PLAY — configuração e execução

## 1. Requisitos
- Node.js 18 ou superior
- Conta no MongoDB Atlas com um banco de dados
- Conta/site no Netlify para publicar

## 2. Configurar localmente
Na pasta `educa-play`, instale as dependências:

```bash
npm install
```

Copie `.env.example` para `.env` e preencha:
- `MONGODB_URI`: endereço de conexão do MongoDB Atlas (com usuário e senha corretos)
- `MONGODB_DB`: nome do banco (pode manter `educaplay`)
- `JWT_SECRET`: chave aleatória longa, com pelo menos 16 caracteres

No MongoDB Atlas, permita conexões do ambiente onde o site será executado (Network Access) e confira usuário/senha do banco (Database Access).

Inicie o projeto com:

```bash
npm run dev
```

Abra o endereço local mostrado pelo Netlify CLI (normalmente `http://localhost:8888`).
**Não** abra `frontend/index.html` diretamente e não use apenas Live Server: isso serve os arquivos estáticos, mas não executa a função `/api` nem o backend.

## 3. Configurar no Netlify publicado
Em Site configuration → Environment variables, cadastre as mesmas três variáveis:
`MONGODB_URI`, `MONGODB_DB` e `JWT_SECRET`.
Depois faça um novo deploy para aplicar as variáveis.

O site utiliza a função `netlify/functions/api.js`, encaminhada pelo redirecionamento `/api/*` de `netlify.toml`.

## 4. Login
- Aluno: a conta precisa existir na coleção `students`.
- Professor/administrador: crie a conta em `admin.html`; ela será salva na coleção `teachers`.
- A senha é armazenada com hash bcrypt, não em texto puro.

## 5. Se continuar falhando
Abra o site, pressione F12 → Network, tente entrar e veja a requisição `api/student/login` ou `api/teacher/login`.
- `404`: função/redirect não publicado corretamente.
- `500`: verifique variáveis e logs da função; normalmente é conexão/configuração do MongoDB ou JWT.
- `401`: usuário/senha incorretos ou conta não cadastrada.
- `Failed to fetch`: o frontend não alcançou a API; confirme que abriu pelo Netlify Dev ou pelo domínio publicado.
