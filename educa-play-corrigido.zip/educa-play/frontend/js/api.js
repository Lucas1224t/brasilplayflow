// Cliente da API: funciona no Netlify publicado e no Netlify Dev local.
const API_BASE = "/api/";

async function requestApi(method, path, data) {
  let response;
  try {
    response = await fetch(API_BASE + String(path).replace(/^\/+/, ""), {
      method,
      headers: {
        "Accept": "application/json",
        ...(data !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(tok() ? { "Authorization": "Bearer " + tok() } : {})
      },
      body: data !== undefined ? JSON.stringify(data) : undefined,
      cache: "no-store"
    });
  } catch (error) {
    console.error("Falha ao conectar à API do Educa Play:", error);
    throw new Error("Não foi possível conectar ao servidor. Abra o projeto pelo Netlify (npm run dev) e confira as variáveis MONGODB_URI e JWT_SECRET.");
  }

  const raw = await response.text();
  let result = {};
  try { result = raw ? JSON.parse(raw) : {}; }
  catch {
    console.error("Resposta inválida da API:", raw.slice(0, 300));
    throw new Error("O servidor respondeu em um formato inválido. Verifique a função /api no Netlify.");
  }

  if (!response.ok) {
    if (response.status === 401 && tok()) {
      sessionStorage.removeItem("token");
      localStorage.removeItem("token");
    }
    throw new Error(result.error || `Erro do servidor (${response.status}).`);
  }
  return result;
}

const tok = () => sessionStorage.getItem("token") || localStorage.getItem("token");
async function call(method, path, data) { return requestApi(method, path, data); }
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
async function sair() {
  sessionStorage.clear();
  localStorage.removeItem("token");
  try { if (typeof limparPerfil === "function") await limparPerfil(); } catch {}
  location.href = "index.html";
}
if (!tok() && /(?:aluno|professor)\.html$/.test(location.pathname)) location.href = "index.html";
