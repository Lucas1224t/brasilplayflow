-- Execute uma vez no banco ja existente. Faca backup antes.
ALTER TABLE ucp_contas MODIFY id_conta INT NULL;
ALTER TABLE ucp_contas ADD COLUMN discord_id VARCHAR(24) NULL UNIQUE, ADD COLUMN discord_username VARCHAR(100) NULL, ADD COLUMN discord_avatar VARCHAR(100) NULL, ADD COLUMN discord_roles TEXT NULL;
CREATE TABLE IF NOT EXISTS ucp_discord_pending (token_hash CHAR(64) PRIMARY KEY, discord_id VARCHAR(24) NOT NULL, discord_username VARCHAR(100) NOT NULL, discord_avatar VARCHAR(100) NULL, discord_roles TEXT NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, expira_em DATETIME NOT NULL, INDEX (expira_em), UNIQUE KEY (discord_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
