-- BPF UCP - tabelas complementares. A GameMode nao usa MySQL: as contas continuam nos arquivos DOF2.
CREATE TABLE IF NOT EXISTS ucp_contas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nick VARCHAR(24) NOT NULL UNIQUE,
  id_conta INT NULL UNIQUE COMMENT 'IDConta da GameMode (opcional quando a conta e criada via Discord)',
  senha_hash VARCHAR(100) NOT NULL COMMENT 'bcrypt da senha do UCP; a senha do jogo nunca e lida',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ultimo_acesso DATETIME NULL,
  ultimo_ip VARCHAR(64) NULL,
  discord_id VARCHAR(24) NULL UNIQUE,
  discord_username VARCHAR(100) NULL,
  discord_avatar VARCHAR(100) NULL,
  discord_roles TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS ucp_discord_pending (
  token_hash CHAR(64) PRIMARY KEY, discord_id VARCHAR(24) NOT NULL, discord_username VARCHAR(100) NOT NULL,
  discord_avatar VARCHAR(100) NULL, discord_roles TEXT NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, expira_em DATETIME NOT NULL, INDEX (expira_em), UNIQUE KEY (discord_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_sessions (
  token_hash CHAR(64) PRIMARY KEY,
  nick VARCHAR(24) NOT NULL,
  csrf CHAR(48) NOT NULL,
  ip VARCHAR(64), ua VARCHAR(255),
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expira_em DATETIME NOT NULL,
  INDEX (nick), INDEX (expira_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_tentativas (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  chave VARCHAR(100) NOT NULL, ip VARCHAR(64) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (chave, criado_em), INDEX (ip, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_acessos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nick VARCHAR(24) NOT NULL, ip VARCHAR(64), ua VARCHAR(255), sucesso TINYINT NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX (nick)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_cargos (
  cargo VARCHAR(30) PRIMARY KEY,
  permissoes TEXT NOT NULL COMMENT 'JSON array de permissoes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_permissoes (
  nick VARCHAR(24) PRIMARY KEY,
  cargo VARCHAR(30) NULL COMMENT 'sobrescreve o cargo vindo do admin do jogo',
  extras TEXT NULL COMMENT 'JSON array de permissoes extras',
  bloqueado TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_noticias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('noticia','atualizacao','evento','manutencao','comunicado') NOT NULL DEFAULT 'noticia',
  titulo VARCHAR(150) NOT NULL, corpo TEXT NOT NULL, autor VARCHAR(24) NOT NULL,
  publicado TINYINT NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, editado_em DATETIME NULL,
  INDEX (tipo, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_arquivos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome_original VARCHAR(200), nome_disco VARCHAR(80) NOT NULL, mime VARCHAR(60) NOT NULL, tamanho INT NOT NULL,
  dono VARCHAR(24) NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_tickets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nick VARCHAR(24) NOT NULL,
  categoria ENUM('suporte','conta','compras','denuncias','bugs','outros') NOT NULL,
  assunto VARCHAR(150) NOT NULL,
  status ENUM('aberto','respondido','fechado') NOT NULL DEFAULT 'aberto',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (nick), INDEX (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_ticket_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NOT NULL, autor VARCHAR(24) NOT NULL, staff TINYINT NOT NULL DEFAULT 0,
  mensagem TEXT NOT NULL, arquivo_id INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (ticket_id),
  FOREIGN KEY (ticket_id) REFERENCES ucp_tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_denuncias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  autor VARCHAR(24) NOT NULL, denunciado VARCHAR(24) NOT NULL, motivo VARCHAR(100) NOT NULL, descricao TEXT NOT NULL,
  status ENUM('aguardando','analise','aceita','recusada','finalizada') NOT NULL DEFAULT 'aguardando',
  responsavel VARCHAR(24) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (autor), INDEX (denunciado), INDEX (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_denuncia_provas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  denuncia_id INT UNSIGNED NOT NULL, arquivo_id INT UNSIGNED NOT NULL,
  FOREIGN KEY (denuncia_id) REFERENCES ucp_denuncias(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_denuncia_msgs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  denuncia_id INT UNSIGNED NOT NULL, autor VARCHAR(24) NOT NULL, staff TINYINT NOT NULL DEFAULT 0,
  mensagem TEXT NOT NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (denuncia_id),
  FOREIGN KEY (denuncia_id) REFERENCES ucp_denuncias(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_produtos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL, descricao VARCHAR(255) NULL,
  tipo ENUM('coins','vip') NOT NULL,
  coins INT NOT NULL DEFAULT 0,
  vip_nivel TINYINT NOT NULL DEFAULT 0 COMMENT '1=VIP Comum, 2=VIP Premium (niveis da GameMode)',
  vip_dias INT NOT NULL DEFAULT 0,
  preco_centavos INT UNSIGNED NOT NULL,
  ativo TINYINT NOT NULL DEFAULT 1, ordem INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_compras (
  id CHAR(36) PRIMARY KEY COMMENT 'identificador unico da transacao',
  nick VARCHAR(24) NOT NULL, produto_id INT UNSIGNED NOT NULL,
  produto_nome VARCHAR(80) NOT NULL, tipo ENUM('coins','vip') NOT NULL,
  coins INT NOT NULL DEFAULT 0, vip_nivel TINYINT NOT NULL DEFAULT 0, vip_dias INT NOT NULL DEFAULT 0,
  valor_centavos INT UNSIGNED NOT NULL,
  status ENUM('pendente','pago','entregue','cancelada','expirada') NOT NULL DEFAULT 'pendente',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, pago_em DATETIME NULL, entregue_em DATETIME NULL,
  INDEX (nick), INDEX (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_pagamentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  compra_id CHAR(36) NOT NULL UNIQUE, gateway VARCHAR(30) NOT NULL,
  gateway_id VARCHAR(80) NULL UNIQUE, valor_centavos INT UNSIGNED NOT NULL,
  status ENUM('pendente','aprovado','recusado','cancelado') NOT NULL DEFAULT 'pendente',
  pix_copia_cola TEXT NULL, pix_qr_base64 MEDIUMTEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, aprovado_em DATETIME NULL,
  FOREIGN KEY (compra_id) REFERENCES ucp_compras(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_entregas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  origem ENUM('compra','ajuste') NOT NULL, compra_id CHAR(36) NULL, nick VARCHAR(24) NOT NULL,
  coins INT NOT NULL DEFAULT 0, vip_nivel TINYINT NOT NULL DEFAULT 0, vip_dias INT NOT NULL DEFAULT 0,
  status ENUM('pendente','enviada','entregue') NOT NULL DEFAULT 'pendente',
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, entregue_em DATETIME NULL,
  UNIQUE KEY uq_compra (compra_id), INDEX (nick, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_transacoes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nick VARCHAR(24) NOT NULL,
  tipo ENUM('compra','recarga','ajuste') NOT NULL,
  descricao VARCHAR(200) NOT NULL, coins INT NOT NULL DEFAULT 0, valor_centavos INT NOT NULL DEFAULT 0,
  ref VARCHAR(40) NULL, criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX (nick)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ucp_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ator VARCHAR(24) NOT NULL, acao VARCHAR(60) NOT NULL, detalhe TEXT NULL, ip VARCHAR(64) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX (ator), INDEX (acao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO ucp_cargos (cargo, permissoes) VALUES
('Helper','["players.ver","tickets.responder"]'),
('Moderador','["players.ver","tickets.responder","denuncias.gerenciar"]'),
('Administrador','["players.ver","tickets.responder","denuncias.gerenciar","noticias.editar","logs.ver"]'),
('Gerente','["players.ver","tickets.responder","denuncias.gerenciar","noticias.editar","logs.ver","produtos.gerenciar","compras.ver","pagamentos.ver"]'),
('Diretor','["players.ver","tickets.responder","denuncias.gerenciar","noticias.editar","logs.ver","produtos.gerenciar","compras.ver","pagamentos.ver","moedas.ajustar"]'),
('Dono','["players.ver","tickets.responder","denuncias.gerenciar","noticias.editar","logs.ver","produtos.gerenciar","compras.ver","pagamentos.ver","pagamentos.confirmar","moedas.ajustar","permissoes.gerenciar"]');
