# Integracao com a GameMode (BPS.pwn)

## O que foi analisado (fatos)
- As contas **nao estao em MySQL**. Ficam em arquivos DOF2: `scriptfiles/Players/Contas/<Nick>.ini` (chaves `Registrado`, `Senha`, `IDConta`) e `<Nick>2.ini` (data de registro/ultimo login). O `a_mysql` e incluido, mas nao existe `mysql_connect` ativo e o sync para a tabela `contas` esta comentado.
- A senha do jogo e **um numero inteiro** (`strval(senha)`) guardado **em texto puro** no `.ini`. Por isso o UCP **nunca le nem usa a senha do jogo**.
- Os dados do personagem (level, dinheiro, VIP...) sao salvos por `SalvarDados`, que fica em arquivos de modulo que nao foram enviados. Por isso o UCP nao le esses `.ini` por chave: a propria GameMode exporta um "status" com variaveis conhecidas (`PlayerInfo[...]`).

## Arquitetura adotada: ponte por arquivos em `scriptfiles/UCP/`
| Pasta | Quem grava | Conteudo |
|---|---|---|
| `Vinculos/<CODIGO>.ini` | GameMode (`/vincularucp`) | Nick, IDConta, Admin, Expira (10 min). O UCP apaga ao usar (uso unico). |
| `Status/<Nick>.ini` | GameMode (a cada ~30s e ao salvar) | Level, Admin, Dinheiro, Banco, Coins, VIP, Org, Cargo, Emprego, Horas... |
| `Entregas/<Nick>.ini` | UCP | Coins, VIPNivel, VIPDias, Ids. A GameMode aplica, **apaga o arquivo antes de aplicar** (nao entrega 2x) e grava a confirmacao. |
| `Confirmacoes/<Nick>.ini` | GameMode | Ids aplicados; o UCP marca como entregue. |

**Crie estas 4 pastas dentro de `scriptfiles/UCP/` antes de subir o servidor** (a DOF2 nao cria pastas). O UCP precisa rodar na mesma maquina (ou com a pasta `scriptfiles` montada) com permissao de leitura e escrita.

## Alteracoes feitas no `BPS.pwn`
1. `CMD:vincularucp` - gera codigo de 8 caracteres (valido por 10 min, 1 uso, cooldown de 15s, invalida o anterior) e mostra num dialog.
2. `UCP_SalvarStatus` - grava o retrato da conta (inclui `pAdmin`, usado para dar acesso de equipe automaticamente).
3. `UCP_ProcessarEntrega` / `NCK::UCP_Tick` (timer de 30s) - aplica moedas (positivas ou negativas, saldo minimo 0) e VIP (`pVIP`, `pDiaVIP`, `DarBeneficio`, igual ao `/darvip`) e confirma.
4. Chamada de `UCP_SalvarStatus` dentro de `OnPlayerSave` e `SetTimer("UCP_Tick", 30000, 1)` junto aos outros timers.
5. Log em `Logs/UCP.ini`.

## Admin do jogo -> cargo no site (automatico)
| Admin no jogo | Cargo no UCP |
|---|---|
| 1 Aprendiz, 2 Estagiario | Helper |
| 3 Auxiliar | Moderador |
| 1337 Master, 1338 Master+ | Administrador |
| 1339 Gerente | Gerente |
| 1340 Diretor | Diretor |
| 1341 Dono, 1342 Fundador | Dono |
O cargo e recalculado a cada requisicao a partir do status do jogo; se o admin for removido no jogo, perde o acesso no site (no maximo ~30s depois). As permissoes de cada cargo ficam no banco (`ucp_cargos`) e sao editaveis no painel (cargo Dono).

## Limitacoes conhecidas (nao inventadas)
- **Historico de punicoes**: a GameMode nao exporta; a tela informa isso.
- **Compra com Moedas VIP dentro do UCP**: nao implementada. Debitar moedas exige confirmacao atomica pelo jogo. Hoje as moedas sao compradas com PIX e o saldo e exibido.
- **Niveis de VIP**: a GameMode so tem VIP Comum (1) e Premium (2) (e Socio 1-3). Os produtos de exemplo usam esses niveis; "Bronze/Prata/Ouro/Diamante" so fazem sentido se voce criar esses niveis no jogo.
- **Ranking/Organizacoes/Equipe** sao calculados a partir dos `Status` dos jogadores que ja entraram desde a instalacao.
- Corrida rara: se o UCP gravar uma entrega exatamente no instante em que a GameMode a apaga, a mescla pode se perder; o UCP reenvia entregas que ficam "pendentes" mas nao as "enviadas". Risco baixo (janela de milissegundos).

## Recomendacao de seguranca (fora do escopo do UCP)
A senha do jogo em texto puro (inteiro no `.ini`) e um risco: quem acessar `scriptfiles` ve todas as senhas. Considere migrar para hash (ex.: `SHA256_PassHash` do plugin sampcrypto/`WP_Hash`) no login/registro. O UCP nao depende disso.
