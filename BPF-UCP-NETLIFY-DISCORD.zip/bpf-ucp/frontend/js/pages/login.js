$('#fLogin').onsubmit = async (e) => { e.preventDefault(); const f = new FormData(e.target); $('#b1').disabled = true;
  try { await post('/api/auth/login', { nick: f.get('nick'), senha: f.get('senha') }); location.href = '/dashboard.html'; } catch (er) { toast(er.message, 'err'); $('#b1').disabled = false; } };
$('#fRegister').onsubmit = async (e) => { e.preventDefault(); const f = new FormData(e.target); $('#bRegister').disabled = true;
  try { const r = await post('/api/auth/discord-register', { ticket: f.get('ticket'), nick: f.get('nick'), senha: f.get('senha'), confirmar: f.get('confirmar') }); location.href = r.redirect || '/dashboard.html'; } catch (er) { toast(er.message, 'err'); $('#bRegister').disabled = false; } };
(async () => {
  const q = new URLSearchParams(location.search);
  if (q.get('discord_register') === '1' && q.get('ticket')) { $('#registerBox').hidden = false; $('#fLogin').hidden = true; $('#discordTicket').value = q.get('ticket'); }
  const erro = q.get('erro');
  if (erro) { const msgs = { discord_state: 'A verificacao expirou. Tente novamente.', discord_oauth: 'Nao foi possivel autenticar no Discord.', discord_user: 'Nao foi possivel identificar sua conta Discord.', discord_guild: 'Voce precisa fazer parte do nosso servidor Discord.', discord_verify: 'Nao foi possivel verificar sua participacao no servidor.', blocked: 'Sua conta esta bloqueada no UCP.' }; toast(msgs[erro] || 'Falha na autenticacao.', 'err'); }
  try { await get('/api/auth/me'); location.href = '/dashboard.html'; } catch (e) { /* nao logado */ }
})();