(async () => {
  try {
    const [s, eq] = await Promise.all([get('/api/public/status'), get('/api/public/equipe')]);
    const sv = s.servidor || { online: false };
    $('#st').innerHTML = `<span class="dot ${sv.online ? 'on' : 'off'}"></span> ${sv.online ? 'ONLINE' : 'OFFLINE'}`;
    $('#pl').textContent = sv.online ? `${sv.players} / ${sv.max}` : '-';
    $('#hn').textContent = sv.online ? sv.hostname : '-';
    $('#discord').href = s.discord || '#'; $('#jogar').href = s.discord || '/login.html';
    $('#news').innerHTML = s.noticias.length ? s.noticias.map((n) => `<div class="card"><span class="badge blue">${esc(n.tipo)}</span><h3>${esc(n.titulo)}</h3><p>${esc(n.resumo)}</p><small>${esc(n.autor)} - ${dt(n.criado_em)}</small></div>`).join('') : '<div class="card empty">Nenhuma novidade publicada.</div>';
    $('#prods').innerHTML = s.produtos.length ? s.produtos.map((p) => `<div class="card"><span class="badge ${p.tipo === 'vip' ? 'red' : 'warn'}">${p.tipo === 'vip' ? 'VIP' : 'MOEDAS'}</span><h3>${esc(p.nome)}</h3><p>${esc(p.descricao || '')}</p><b>${brl(p.preco_centavos)}</b><p><a class="btn sm" href="/loja.html">Comprar no UCP</a></p></div>`).join('') : '<div class="card empty">Loja em breve.</div>';
    $('#team').innerHTML = eq.equipe.length ? tabela([['Nick', (r) => esc(r.nick)], ['Cargo', (r) => esc(r.cargo)], ['Status', (r) => `<span class="dot ${r.online ? 'on' : ''}"></span> ${r.online ? 'Online' : 'Offline'}`]], eq.equipe) : '<div class="empty">A equipe aparece aqui conforme os administradores entram no jogo.</div>';
  } catch (e) { toast(e.message, 'err'); }
})();
