shell('ranking', 'Ranking', async (v) => {
  const d = await get('/api/player/ranking');
  const T = (t, cols, rows) => `<div class="card"><h3>${t}</h3>${tabela(cols, rows, 'Sem dados ainda.')}</div>`;
  const base = (f) => [['#', (r) => r.pos], ['Jogador', (r) => esc(r.nick)], [f, (r) => num(r.valor)], ['Org', (r) => esc(r.org)]];
  v.innerHTML = `<div class="note">Ranking dos jogadores que ja entraram no servidor desde a instalacao do UCP.</div><div class="grid g2">${T('Niveis', base('Nivel'), d.niveis)}${T('Horas jogadas', base('Horas'), d.horas)}${T('Dinheiro (mao + banco)', base('R$'), d.dinheiro)}${T('Organizacoes', [['#', (r) => r.pos], ['Organizacao', (r) => esc(r.nome)], ['Membros', (r) => r.membros], ['Soma de levels', (r) => r.level]], d.organizacoes)}</div>`;
});
