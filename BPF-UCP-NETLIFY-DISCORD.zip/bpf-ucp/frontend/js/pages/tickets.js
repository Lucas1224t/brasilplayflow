shell('tickets', 'Tickets', async (v) => {
  const CAT = { suporte: 'Suporte geral', conta: 'Problemas com conta', compras: 'Compras', denuncias: 'Denuncias', bugs: 'Bugs', outros: 'Outros assuntos' };
  async function lista() {
    const d = await get('/api/tickets');
    $('#lst').innerHTML = tabela([['#', (r) => r.id], ['Categoria', (r) => esc(CAT[r.categoria])], ['Assunto', (r) => esc(r.assunto)], ['Status', (r) => badge(r.status)], ['Atualizado', (r) => dt(r.atualizado_em)], ['', (r) => `<button class="btn sm ghost" data-id="${r.id}">Abrir</button>`]], d.tickets, 'Nenhum ticket.');
    document.querySelectorAll('[data-id]').forEach((b) => { b.onclick = () => detalhe(b.dataset.id); });
  }
  async function detalhe(id) {
    const d = await get('/api/tickets/' + id); const t = d.ticket;
    $('#det').innerHTML = `<div class="card"><div class="row"><h3>#${t.id} - ${esc(t.assunto)}</h3><span class="sp"></span>${badge(t.status)} ${t.status !== 'fechado' ? '<button class="btn sm ghost" id="fc">Fechar ticket</button>' : ''}</div>
    ${d.mensagens.map((m) => `<div class="msg ${m.staff ? 'staff' : ''}"><small>${esc(m.autor)}${m.staff ? ' (equipe)' : ''} - ${dt(m.criado_em)}</small><br>${esc(m.mensagem).replace(/\n/g, '<br>')}${m.arquivo_id ? `<br><a target="_blank" rel="noopener" href="/api/arquivos/${m.arquivo_id}">Ver anexo</a>` : ''}</div>`).join('')}
    ${t.status === 'fechado' ? '' : '<form id="fm"><label>Mensagem</label><textarea name="mensagem" required></textarea><label>Anexo (imagem, opcional)</label><input type="file" name="anexos" accept="image/*"><p></p><button class="btn">Enviar</button></form>'}</div>`;
    const fm = $('#fm'); if (fm) fm.onsubmit = (e) => { e.preventDefault(); guard(async () => { await post(`/api/tickets/${id}/mensagens`, new FormData(fm)); detalhe(id); lista(); }); };
    const fc = $('#fc'); if (fc) fc.onclick = () => guard(async () => { await post(`/api/tickets/${id}/fechar`); detalhe(id); lista(); });
    $('#det').scrollIntoView({ behavior: 'smooth' });
  }
  v.innerHTML = `<div class="grid g2"><div class="card"><h3>Abrir ticket</h3><form id="f"><label>Categoria</label><select name="categoria">${Object.entries(CAT).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select><label>Assunto</label><input name="assunto" required minlength="4" maxlength="150"><label>Mensagem</label><textarea name="mensagem" required minlength="10"></textarea><label>Anexo (imagem, opcional)</label><input type="file" name="anexos" accept="image/*"><p></p><button class="btn">Abrir ticket</button></form></div>
  <div class="card"><h3>Meus tickets</h3><div id="lst"><div class="loader"></div></div></div></div><p></p><div id="det"></div>`;
  $('#f').onsubmit = (e) => { e.preventDefault(); guard(async () => { const r = await post('/api/tickets', new FormData(e.target)); toast('Ticket #' + r.id + ' aberto.', 'ok'); e.target.reset(); lista(); detalhe(r.id); }); };
  lista();
});
