shell('organizacoes', 'Organizacoes', async (v) => {
  const d = await get('/api/player/organizacoes');
  v.innerHTML = d.organizacoes.length ? '<div class="grid g2">' + d.organizacoes.map((o) => `<div class="card"><h3>${esc(o.nome)}</h3><p><span class="badge blue">${o.total} membro(s)</span></p>${tabela([['Membro', (m) => esc(m.nick) + (m.lider ? ' <span class="badge warn">Lider</span>' : '')], ['Cargo', (m) => m.cargo], ['Level', (m) => m.level], ['', (m) => `<span class="dot ${m.online ? 'on' : ''}"></span>`]], o.membros)}</div>`).join('') + '</div>' : '<div class="card empty">Nenhuma organizacao com membros registrados ainda.</div>';
});
