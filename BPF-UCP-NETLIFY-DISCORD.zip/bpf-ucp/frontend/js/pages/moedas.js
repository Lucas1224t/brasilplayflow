shell('moedas', 'Moedas VIP', async (v) => {
  const [m, p, e] = await Promise.all([get('/api/loja/moedas'), get('/api/loja/produtos'), get('/api/loja/entregas')]);
  v.innerHTML = `<div class="grid g2"><div class="card stat"><small>Saldo atual (no jogo)</small><b>${m.saldo == null ? '-' : num(m.saldo)}</b><p class="note">${m.atualizadoEm ? 'Atualizado em ' + dt(m.atualizadoEm) : 'Entre no jogo para sincronizar.'}</p></div>
  <div class="card"><h3>Comprar moedas</h3>${p.produtos.filter((x) => x.tipo === 'coins').map((x) => `<div class="row"><span>${num(x.coins)} moedas</span><span class="sp"></span><b>${brl(x.preco_centavos)}</b><a class="btn sm" href="/loja.html">Comprar</a></div>`).join('') || '<div class="empty">Sem pacotes.</div>'}</div></div><p></p>
  <div class="card"><h3>Historico de recargas</h3>${tabela([['Data', (r) => dt(r.criado_em)], ['Pacote', (r) => esc(r.descricao)], ['Moedas', (r) => num(r.coins)], ['Valor', (r) => brl(r.valor_centavos)]], m.recargas, 'Nenhuma recarga.')}</div><p></p>
  <div class="card"><h3>Ajustes da equipe</h3>${tabela([['Data', (r) => dt(r.criado_em)], ['Descricao', (r) => esc(r.descricao)], ['Moedas', (r) => num(r.coins)]], m.ajustes, 'Nenhum ajuste.')}</div><p></p>
  <div class="card"><h3>Entregas no jogo</h3>${tabela([['Data', (r) => dt(r.criado_em)], ['Origem', (r) => esc(r.origem)], ['Moedas', (r) => num(r.coins)], ['VIP', (r) => r.vip_nivel ? (r.vip_nivel === 2 ? 'Premium ' : 'Comum ') + r.vip_dias + 'd' : '-'], ['Status', (r) => badge(r.status)], ['Entregue em', (r) => dt(r.entregue_em)]], e.entregas, 'Nenhuma entrega.')}</div>
  <p class="note">O jogo ainda nao registra o gasto de moedas dentro do servidor, entao nao ha historico de utilizacao disponivel.</p>`;
});
