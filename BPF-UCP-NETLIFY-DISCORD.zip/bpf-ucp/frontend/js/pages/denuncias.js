shell('denuncias', 'Denuncias', async (v, me) => {
  async function lista() {
    const d = await get('/api/denuncias');
    $('#lst').innerHTML = tabela([['#', (r) => r.id], ['Denunciado', (r) => esc(r.denunciado)], ['Motivo', (r) => esc(r.motivo)], ['Status', (r) => badge(r.status)], ['Atualizada', (r) => dt(r.atualizado_em)], ['', (r) => `<button class="btn sm ghost" data-id="${r.id}">Abrir</button>`]], d.denuncias, 'Voce nao abriu denuncias.');
    document.querySelectorAll('[data-id]').forEach((b) => { b.onclick = () => detalhe(b.dataset.id); });
  }
  async function detalhe(id) {
    const d = await get('/api/denuncias/' + id); const x = d.denuncia;
    $('#det').innerHTML = `<div class="card"><div class="row"><h3>Denuncia #${x.id} contra ${esc(x.denunciado)}</h3><span class="sp"></span>${badge(x.status)}</div><p><b>Motivo:</b> ${esc(x.motivo)}</p><p>${esc(x.descricao).replace(/\n/g, '<br>')}</p>
    ${d.provas.map((p, i) => `<a class="btn sm ghost" target="_blank" rel="noopener" href="/api/arquivos/${p.arquivo_id}">Prova ${i + 1}</a> `).join('')}
    <h3>Andamento</h3>${d.mensagens.length ? d.mensagens.map((m) => `<div class="msg ${m.staff ? 'staff' : ''}"><small>${esc(m.autor)}${m.staff ? ' (equipe)' : ''} - ${dt(m.criado_em)}</small><br>${esc(m.mensagem).replace(/\n/g, '<br>')}</div>`).join('') : '<div class="empty">Sem respostas ainda.</div>'}
    ${['recusada', 'finalizada'].includes(x.status) ? '' : '<form id="fm"><label>Responder</label><textarea name="mensagem" required></textarea><p></p><button class="btn">Enviar</button></form>'}</div>`;
    const fm = $('#fm'); if (fm) fm.onsubmit = (e) => { e.preventDefault(); guard(async () => { await post(`/api/denuncias/${id}/mensagens`, { mensagem: new FormData(fm).get('mensagem') }); detalhe(id); }); };
    $('#det').scrollIntoView({ behavior: 'smooth' });
  }
  v.innerHTML = `<div class="grid g2"><div class="card"><h3>Abrir denuncia</h3><form id="f"><label>Jogador denunciado (nick)</label><input name="denunciado" required maxlength="24"><label>Motivo</label><input name="motivo" required maxlength="100"><label>Descreva o ocorrido (minimo 20 caracteres)</label><textarea name="descricao" required minlength="20"></textarea><label>Provas (imagens JPG/PNG/WEBP/GIF, ate 5 de 5MB)</label><input type="file" name="provas" accept="image/*" multiple><p></p><button class="btn">Enviar denuncia</button></form></div>
  <div class="card"><h3>Minhas denuncias</h3><div id="lst"><div class="loader"></div></div></div></div><p></p><div id="det"></div>`;
  $('#f').onsubmit = (e) => { e.preventDefault(); guard(async () => { const r = await post('/api/denuncias', new FormData(e.target)); toast('Denuncia #' + r.id + ' enviada.', 'ok'); e.target.reset(); lista(); }); };
  lista();
});
