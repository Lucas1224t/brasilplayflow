shell('dashboard', 'Visao geral', async (v) => {
  const d = await get('/api/player/painel'); const j = d.jogo;
  if (!j) { v.innerHTML = `<div class="card"><h3>Ola, ${esc(d.nick)}</h3><div class="note">${esc(d.aviso)}</div></div>`; return; }
  const vip = j.vip === 2 ? 'VIP Premium' : j.vip === 1 ? 'VIP Comum' : (j.socio ? 'Socio ' + j.socio : 'Gratis');
  const S = (t, val) => `<div class="card stat"><small>${t}</small><b>${val}</b></div>`;
  v.innerHTML = `<div class="card row"><div class="brand"><span>${esc(d.nick.charAt(0))}</span></div><div><h2>${esc(d.nick)}</h2><span class="dot ${j.online ? 'on' : ''}"></span> ${j.online ? 'Online no servidor' : 'Offline'} ${d.cargoUcp ? '<span class="badge red">' + esc(d.cargoUcp) + '</span>' : ''}</div></div><p></p>
  <div class="grid g4">${S('ID da conta', j.idConta)}${S('Nivel', j.level)}${S('Dinheiro em maos', 'R$ ' + num(j.dinheiro))}${S('Banco', 'R$ ' + num(j.banco))}${S('Moedas VIP', num(j.coins))}${S('VIP atual', esc(vip) + (j.vip ? ' (' + j.diaVip + 'd)' : ''))}${S('Organizacao', esc(j.organizacao))}${S('Profissao', esc(j.emprego))}${S('Horas jogadas', num(j.horas))}${S('Registro', esc(j.registro))}${S('Ultimo acesso', esc(j.ultimoLogin))}${S('Vinculado ao UCP em', dt(d.vinculadoEm))}</div>
  <p class="note">Dados enviados pelo jogo a cada ~30 segundos. Ultima atualizacao: ${dt(j.atualizado)}.</p>`;
});
