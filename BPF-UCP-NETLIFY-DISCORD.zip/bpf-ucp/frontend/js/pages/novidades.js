shell('novidades', 'Novidades', async (v) => {
  const T = { '': 'Todas', noticia: 'Noticias', atualizacao: 'Atualizacoes', evento: 'Eventos', manutencao: 'Manutencoes', comunicado: 'Comunicados oficiais' };
  v.innerHTML = `<div class="row">${Object.entries(T).map(([k, n]) => `<button class="btn ghost sm" data-t="${k}">${n}</button>`).join('')}</div><p></p><div class="grid" id="l"><div class="loader"></div></div>`;
  async function carregar(t) {
    const d = await get('/api/public/novidades' + (t ? '?tipo=' + t : ''));
    $('#l').innerHTML = d.novidades.length ? d.novidades.map((n) => `<div class="card"><span class="badge blue">${esc(T[n.tipo] || n.tipo)}</span><h3>${esc(n.titulo)}</h3><p>${esc(n.corpo).replace(/\n/g, '<br>')}</p><small>${esc(n.autor)} - ${dt(n.criado_em)}</small></div>`).join('') : '<div class="card empty">Nada publicado nesta categoria.</div>';
  }
  document.querySelectorAll('[data-t]').forEach((b) => { b.onclick = () => guard(() => carregar(b.dataset.t)); });
  carregar('');
});
