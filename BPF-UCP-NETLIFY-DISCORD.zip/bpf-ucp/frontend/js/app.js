/* Utilitarios compartilhados do UCP BPF. Sem localStorage como banco: todo dado vem da API. */
const ICON = {
  home: '<path d="M3 11l9-8 9 8M5 10v10h14V10"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>', flag: '<path d="M5 21V4h12l-2 4 2 4H5"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>', news: '<path d="M4 4h14v16H6a2 2 0 01-2-2zM8 8h6M8 12h6M8 16h4"/>', shop: '<path d="M4 7h16l-1.5 12h-13zM8 7a4 4 0 018 0"/>',
  coin: '<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.5 9.5h4a1.5 1.5 0 010 3h-3a1.5 1.5 0 000 3h4"/>', org: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20c0-4 3-6 6-6s6 2 6 6M15 15c3-.5 6 1 6 5"/>',
  rank: '<path d="M7 20V10M12 20V4M17 20v-7"/>', admin: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>', out: '<path d="M10 4H4v16h6M15 8l5 4-5 4M20 12H9"/>', menu: '<path d="M4 6h16M4 12h16M4 18h16"/>'
};
const ico = (n) => `<svg class="ico" viewBox="0 0 24 24">${ICON[n] || ''}</svg>`;
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const brl = (c) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const num = (n) => Number(n || 0).toLocaleString('pt-BR');
const dt = (d) => d ? new Date(d).toLocaleString('pt-BR') : '-';
let CSRF = '';
function toast(msg, tipo) { const t = document.createElement('div'); t.className = 'toast ' + (tipo || ''); t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 4500); }
async function api(method, url, body) {
  const o = { method, headers: {}, credentials: 'same-origin' };
  if (CSRF) o.headers['x-csrf-token'] = CSRF;
  if (body instanceof FormData) o.body = body; else if (body) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
  const r = await fetch(url, o);
  let j = {}; try { j = await r.json(); } catch (e) { /* sem corpo */ }
  if (!r.ok) { const e = new Error(j.erro || 'Erro ' + r.status); e.status = r.status; throw e; }
  return j;
}
const get = (u) => api('GET', u), post = (u, b) => api('POST', u, b);
async function guard(fn) { try { return await fn(); } catch (e) { toast(e.message, 'err'); } }
const STATUS_TXT = { aguardando: 'Aguardando analise', analise: 'Em analise', aceita: 'Aceita', recusada: 'Recusada', finalizada: 'Finalizada', aberto: 'Aberto', respondido: 'Respondido', fechado: 'Fechado', pendente: 'Pendente', pago: 'Pago', entregue: 'Entregue', cancelada: 'Cancelada', expirada: 'Expirada', enviada: 'Enviada ao jogo', aprovado: 'Aprovado' };
const STATUS_COR = { aguardando: 'warn', analise: 'blue', aceita: 'ok', recusada: 'red', finalizada: '', aberto: 'warn', respondido: 'blue', fechado: '', pendente: 'warn', pago: 'blue', entregue: 'ok', cancelada: 'red', expirada: '', enviada: 'blue', aprovado: 'ok' };
const badge = (s) => `<span class="badge ${STATUS_COR[s] || ''}">${esc(STATUS_TXT[s] || s)}</span>`;
const $ = (s, r) => (r || document).querySelector(s);
const MENU = [
  ['PAINEL', [['dashboard', 'Visao geral', 'home']]],
  ['CONTA', [['conta', 'Minha conta', 'user']]],
  ['SUPORTE', [['denuncias', 'Denuncias', 'flag'], ['tickets', 'Tickets', 'chat'], ['novidades', 'Novidades', 'news']]],
  ['LOJA', [['loja', 'Loja VIP', 'shop'], ['moedas', 'Moedas VIP', 'coin']]],
  ['COMUNIDADE', [['organizacoes', 'Organizacoes', 'org'], ['ranking', 'Ranking', 'rank']]]
];
// Monta o layout do painel e entrega a area principal para cada pagina.
async function shell(ativo, titulo, render) {
  document.body.innerHTML = '<div class="layout"><aside class="side" id="side"></aside><main class="main"><div class="top"><div class="row"><button class="btn ghost sm menu-btn" id="mb">' + ico('menu') + '</button><h1>' + esc(titulo) + '</h1></div><div class="row" id="usr"></div></div><div id="view"><div class="loader"></div></div></main></div>';
  let me;
  try { me = await get('/api/auth/me'); } catch (e) { location.href = '/login.html'; return; }
  CSRF = me.csrf;
  let h = '<div class="brand">BPF <span>UCP</span></div>';
  for (const [sec, items] of MENU) { h += `<div class="sec">${sec}</div>`; for (const [id, nome, ic] of items) h += `<a class="nav ${id === ativo ? 'on' : ''}" href="/${id}.html">${ico(ic)}${nome}</a>`; }
  if (me.cargo) h += `<div class="sec">EQUIPE</div><a class="nav ${ativo === 'admin' ? 'on' : ''}" href="/admin.html">${ico('admin')}Painel admin</a>`;
  h += `<div class="sec">CONTA</div><a class="nav" href="#" id="sair">${ico('out')}Sair</a>`;
  $('#side').innerHTML = h;
  $('#usr').innerHTML = `<span class="badge blue">${esc(me.nick)}</span>${me.cargo ? '<span class="badge red">' + esc(me.cargo) + '</span>' : ''}`;
  $('#mb').onclick = () => $('#side').classList.toggle('open');
  $('#sair').onclick = async (e) => { e.preventDefault(); await post('/api/auth/logout'); location.href = '/'; };
  await guard(() => render($('#view'), me));
}
function tabela(cols, rows, vazio) {
  if (!rows.length) return `<div class="empty">${esc(vazio || 'Nada por aqui ainda.')}</div>`;
  return `<div class="scroll"><table><thead><tr>${cols.map((c) => '<th>' + esc(c[0]) + '</th>').join('')}</tr></thead><tbody>${rows.map((r) => '<tr>' + cols.map((c) => '<td>' + c[1](r) + '</td>').join('') + '</tr>').join('')}</tbody></table></div>`;
}
