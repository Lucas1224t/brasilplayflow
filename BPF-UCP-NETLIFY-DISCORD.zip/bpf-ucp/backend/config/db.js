const mysql = require('mysql2/promise');
const { cfg } = require('./env');
let pool;
function getPool() {
  if (!pool) pool = mysql.createPool({ ...cfg.db, waitForConnections: true, connectionLimit: 10, charset: 'utf8mb4', namedPlaceholders: false });
  return pool;
}
// Sempre consultas parametrizadas (?), nunca concatenacao -> protecao contra SQL Injection
const query = async (sql, params = []) => (await getPool().execute(sql, params))[0];
const one = async (sql, params = []) => (await query(sql, params))[0] || null;
async function tx(fn) {
  const c = await getPool().getConnection();
  try {
    await c.beginTransaction();
    const r = await fn(c);
    await c.commit();
    return r;
  } catch (e) { await c.rollback(); throw e; } finally { c.release(); }
}
module.exports = { query, one, tx, getPool };
