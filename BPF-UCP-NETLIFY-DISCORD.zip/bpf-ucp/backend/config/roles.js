// Escala de admin do jogo (RankAdmin2 na GameMode) -> cargo do UCP
const GAME_RANKS = {
  1: 'Aprendiz', 2: 'Estagiario', 3: 'Auxiliar', 1337: 'Master', 1338: 'Master+',
  1339: 'Gerente', 1340: 'Diretor', 1341: 'Dono', 1342: 'Fundador'
};
function cargoFromAdmin(level) {
  const n = Number(level) || 0;
  if (n >= 1341) return 'Dono';
  if (n === 1340) return 'Diretor';
  if (n === 1339) return 'Gerente';
  if (n >= 1337) return 'Administrador';
  if (n === 3) return 'Moderador';
  if (n >= 1) return 'Helper';
  return null;
}
function rankName(level) { return GAME_RANKS[Number(level)] || (Number(level) > 0 ? 'Admin ' + level : null); }
const PERMISSOES = [
  'players.ver', 'denuncias.gerenciar', 'tickets.responder', 'noticias.editar', 'produtos.gerenciar',
  'compras.ver', 'pagamentos.ver', 'pagamentos.confirmar', 'moedas.ajustar', 'logs.ver', 'permissoes.gerenciar'
];
const PADRAO = {
  Helper: ['players.ver', 'tickets.responder'],
  Ajudante: ['players.ver', 'tickets.responder'],
  Suporte: ['players.ver', 'tickets.responder'],
  Moderador: ['players.ver', 'tickets.responder', 'denuncias.gerenciar'],
  Supervisor: ['players.ver', 'tickets.responder', 'denuncias.gerenciar'],
  Coordenador: ['players.ver', 'tickets.responder', 'denuncias.gerenciar', 'logs.ver'],
  Administrador: ['players.ver', 'tickets.responder', 'denuncias.gerenciar', 'noticias.editar', 'logs.ver'],
  Gerente: ['players.ver', 'tickets.responder', 'denuncias.gerenciar', 'noticias.editar', 'logs.ver', 'produtos.gerenciar', 'compras.ver', 'pagamentos.ver'],
  Subdiretor: PERMISSOES.slice(), Diretor: PERMISSOES.slice(),
  Dono: PERMISSOES.slice(), Fundador: PERMISSOES.slice(), 'Vice-Fundador': PERMISSOES.slice(),
  'Administrador-Geral': PERMISSOES.slice(), 'Administrador Master': PERMISSOES.slice()
};
module.exports = { GAME_RANKS, cargoFromAdmin, rankName, PERMISSOES, PADRAO };
