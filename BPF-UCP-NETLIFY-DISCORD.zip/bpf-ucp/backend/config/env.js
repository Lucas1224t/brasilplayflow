require('dotenv').config();
const path = require('path');
const e = process.env;
const prod = e.NODE_ENV === 'production';
const cfg = {
  prod,
  port: parseInt(e.PORT || '3000', 10),
  publicUrl: e.PUBLIC_URL || '',
  db: { host: e.DB_HOST || '127.0.0.1', port: parseInt(e.DB_PORT || '3306', 10), user: e.DB_USER, password: e.DB_PASS, database: e.DB_NAME },
  scriptfiles: e.SAMP_SCRIPTFILES ? path.resolve(e.SAMP_SCRIPTFILES) : null,
  samp: { host: e.SAMP_HOST || '127.0.0.1', port: parseInt(e.SAMP_PORT || '7777', 10) },
  discord: {
    inviteUrl: e.DISCORD_URL || 'https://discord.gg/tWkKhgyMYn',
    clientId: e.DISCORD_CLIENT_ID || '', clientSecret: e.DISCORD_CLIENT_SECRET || '',
    botToken: e.DISCORD_BOT_TOKEN || '', guildId: e.DISCORD_GUILD_ID || '',
    redirectUri: e.DISCORD_REDIRECT_URI || '', founderId: e.FOUNDER_DISCORD_ID || '',
    roles: {
      Fundador: e.ROLE_FOUNDER_ID || '', Dono: e.ROLE_OWNER_ID || '', ViceFundador: e.ROLE_VICE_FOUNDER_ID || '',
      Diretor: e.ROLE_DIRECTOR_ID || '', Subdiretor: e.ROLE_SUBDIRECTOR_ID || '', Gerente: e.ROLE_MANAGER_ID || '',
      AdministradorGeral: e.ROLE_ADMIN_GENERAL_ID || '', AdministradorMaster: e.ROLE_ADMIN_MASTER_ID || '',
      Administrador: e.ROLE_ADMIN_ID || '', Coordenador: e.ROLE_COORDINATOR_ID || '', Supervisor: e.ROLE_SUPERVISOR_ID || '',
      Moderador: e.ROLE_MODERATOR_ID || '', Ajudante: e.ROLE_HELPER_ID || '', Suporte: e.ROLE_SUPPORT_ID || ''
    }
  },
  gateway: e.GATEWAY || 'manual',
  mpToken: e.MP_ACCESS_TOKEN || '',
  webhookBase: e.WEBHOOK_BASE || e.PUBLIC_URL || '',
  uploadDir: path.resolve(__dirname, '../../storage/uploads'),
};
function validate() {
  const miss = [];
  if (!cfg.db.user) miss.push('DB_USER');
  if (!cfg.db.database) miss.push('DB_NAME');
  if (prod && (!cfg.discord.clientId || !cfg.discord.clientSecret || !cfg.discord.botToken || !cfg.discord.guildId || !cfg.discord.redirectUri)) miss.push('DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_BOT_TOKEN, DISCORD_GUILD_ID e DISCORD_REDIRECT_URI');
  if (cfg.gateway === 'mercadopago' && !cfg.mpToken) miss.push('MP_ACCESS_TOKEN');
  if (miss.length) throw new Error('Variaveis de ambiente ausentes no .env: ' + miss.join(', '));
}
module.exports = { cfg, validate };
