// Mercado Pago (PIX). NAO testado contra a API real neste ambiente: valide com suas credenciais em modo de teste.
const crypto = require('crypto');
const { cfg } = require('../../config/env');
const API = 'https://api.mercadopago.com';
const hdr = (extra = {}) => ({ Authorization: 'Bearer ' + cfg.mpToken, 'Content-Type': 'application/json', ...extra });
module.exports = {
  nome: 'mercadopago',
  async criarCobranca({ compraId, valorCentavos, descricao, email }) {
    const r = await fetch(API + '/v1/payments', {
      method: 'POST', headers: hdr({ 'X-Idempotency-Key': compraId }),
      body: JSON.stringify({
        transaction_amount: valorCentavos / 100, description: descricao, payment_method_id: 'pix',
        external_reference: compraId, payer: { email: email || 'comprador@bpf.local' },
        notification_url: cfg.webhookBase + '/api/webhooks/mercadopago'
      })
    });
    const j = await r.json();
    if (!r.ok) throw new Error('Gateway recusou a cobranca: ' + (j.message || r.status));
    const td = (j.point_of_interaction || {}).transaction_data || {};
    return { gatewayId: String(j.id), pixCopiaCola: td.qr_code || null, pixQrBase64: td.qr_code_base64 || null };
  },
  // Verificacao legitima: nunca confia no corpo do webhook, consulta o pagamento direto no gateway.
  async consultar(gatewayId) {
    const r = await fetch(API + '/v1/payments/' + encodeURIComponent(gatewayId), { headers: hdr() });
    const j = await r.json();
    if (!r.ok) throw new Error('Falha ao consultar pagamento: ' + (j.message || r.status));
    return { status: j.status === 'approved' ? 'aprovado' : (['rejected', 'cancelled'].includes(j.status) ? 'recusado' : 'pendente'),
      valorCentavos: Math.round(Number(j.transaction_amount) * 100), compraId: j.external_reference };
  }
};
