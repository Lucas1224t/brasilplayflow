const { cfg } = require('../../config/env');
const gws = { manual: require('./manual'), mercadopago: require('./mercadopago') };
module.exports = { atual: () => { const g = gws[cfg.gateway]; if (!g) throw new Error('GATEWAY invalido: ' + cfg.gateway); return g; }, porNome: (n) => gws[n] };
