// Gateway "manual": o jogador paga via PIX combinado com a equipe e a equipe confirma no painel admin.
module.exports = {
  nome: 'manual',
  async criarCobranca({ compraId, valorCentavos }) {
    return { gatewayId: null, pixCopiaCola: null, pixQrBase64: null, instrucoes: 'Pagamento manual: abra um ticket (categoria Compras) com o codigo ' + compraId + ' e envie o comprovante. A equipe confirma e a entrega e automatica.' };
  },
  async consultar() { throw new Error('gateway manual nao possui consulta'); }
};
