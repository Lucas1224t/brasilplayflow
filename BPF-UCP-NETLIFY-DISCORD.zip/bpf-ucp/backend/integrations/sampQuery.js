// Consulta real ao servidor SA-MP via protocolo UDP de query (opcode 'i').
const dgram = require('dgram');
const dns = require('dns').promises;
async function info(host, port, timeoutMs = 2000) {
  let ip = host;
  if (!/^\d+\.\d+\.\d+\.\d+$/.test(host)) ip = (await dns.lookup(host, { family: 4 })).address;
  const octets = ip.split('.').map(Number);
  const pkt = Buffer.alloc(11);
  pkt.write('SAMP', 0, 'latin1');
  octets.forEach((o, i) => pkt.writeUInt8(o, 4 + i));
  pkt.writeUInt16LE(port, 8);
  pkt.write('i', 10, 'latin1');
  return new Promise((resolve) => {
    const sock = dgram.createSocket('udp4');
    const done = (v) => { try { sock.close(); } catch (e) { /* ja fechado */ } resolve(v); };
    const t = setTimeout(() => done({ online: false }), timeoutMs);
    sock.on('error', () => { clearTimeout(t); done({ online: false }); });
    sock.on('message', (msg) => {
      clearTimeout(t);
      try {
        let o = 11;
        const password = msg.readUInt8(o); o += 1;
        const players = msg.readUInt16LE(o); o += 2;
        const max = msg.readUInt16LE(o); o += 2;
        const hl = msg.readUInt32LE(o); o += 4;
        const hostname = msg.toString('latin1', o, o + hl);
        done({ online: true, players, max, hostname, password: !!password });
      } catch (e) { done({ online: false }); }
    });
    sock.send(pkt, port, ip, (err) => { if (err) { clearTimeout(t); done({ online: false }); } });
  });
}
module.exports = { info };
