// Leitor/escritor do formato DOF2 (Chave=Valor) usado pela GameMode.
const fs = require('fs');
const path = require('path');

const NICK_RE = /^[A-Za-z0-9_\[\]\.\$=@()]{3,24}$/;
const CODE_RE = /^[A-Z2-9]{8}$/;

function parse(text) {
  const out = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('//') || line.startsWith(';')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    out[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return out;
}
function readFile(file) {
  try { return parse(fs.readFileSync(file, 'latin1')); } catch (e) { if (e.code === 'ENOENT') return null; throw e; }
}
// escrita atomica: grava em .tmp e renomeia, para a GameMode nunca ler arquivo pela metade
function writeFile(file, obj) {
  const body = Object.entries(obj).map(([k, v]) => `${k}=${v}`).join('\r\n') + '\r\n';
  const tmp = file + '.tmp' + process.pid;
  fs.writeFileSync(tmp, body, 'latin1');
  fs.renameSync(tmp, file);
}
const int = (v, d = 0) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
function safeJoin(base, ...parts) {
  const full = path.resolve(base, ...parts);
  if (!full.startsWith(path.resolve(base) + path.sep)) throw new Error('caminho invalido');
  return full;
}
module.exports = { parse, readFile, writeFile, int, safeJoin, NICK_RE, CODE_RE };
