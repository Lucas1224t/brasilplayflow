const crypto = require('crypto');
const db = require('../config/db');
const bridge = require('./bridge');
const audit = require('./audit');
const gateways = require('../integrations/gateways');

async function criarCompra(nick, produtoId, email, ip) {
  const p = await db.one('SELECT * FROM ucp_produtos WHERE id=? AND ativo=1', [produtoId]); // preco SEMPRE vem do banco
  if (!p) throw new Error('Produto indisponivel.');
  const id = crypto.randomUUID();
  const gw = gateways.atual();
  await db.query('INSERT INTO ucp_compras (id,nick,produto_id,produto_nome,tipo,coins,vip_nivel,vip_dias,valor_centavos) VALUES (?,?,?,?,?,?,?,?,?)',
    [id, nick, p.id, p.nome, p.tipo, p.coins, p.vip_nivel, p.vip_dias, p.preco_centavos]);
  let c;
  try { c = await gw.criarCobranca({ compraId: id, valorCentavos: p.preco_centavos, descricao: p.nome + ' - BPF', email }); }
  catch (e) { await db.query("UPDATE ucp_compras SET status='cancelada' WHERE id=?", [id]); throw e; }
  await db.query('INSERT INTO ucp_pagamentos (compra_id,gateway,gateway_id,valor_centavos,pix_copia_cola,pix_qr_base64) VALUES (?,?,?,?,?,?)',
    [id, gw.nome, c.gatewayId, p.preco_centavos, c.pixCopiaCola, c.pixQrBase64]);
  await audit.log(nick, 'compra.criar', id + ' ' + p.nome, ip);
  return { compraId: id, valorCentavos: p.preco_centavos, pixCopiaCola: c.pixCopiaCola, pixQrBase64: c.pixQrBase64, instrucoes: c.instrucoes || null };
}

// Aprova de forma idempotente: so a primeira chamada gera entrega (trava de linha + UNIQUE em ucp_entregas.compra_id).
async function aprovar(compraId, valorPagoCentavos, ator, ip) {
  const r = await db.tx(async (c) => {
    const [[comp]] = await c.execute('SELECT * FROM ucp_compras WHERE id=? FOR UPDATE', [compraId]);
    if (!comp) throw new Error('Compra inexistente.');
    if (comp.status !== 'pendente') return { jaProcessada: true };
    if (valorPagoCentavos != null && valorPagoCentavos < comp.valor_centavos) throw new Error('Valor pago menor que o da compra.');
    await c.execute("UPDATE ucp_pagamentos SET status='aprovado', aprovado_em=NOW() WHERE compra_id=?", [compraId]);
    await c.execute("UPDATE ucp_compras SET status='pago', pago_em=NOW() WHERE id=?", [compraId]);
    const [ins] = await c.execute("INSERT INTO ucp_entregas (origem,compra_id,nick,coins,vip_nivel,vip_dias) VALUES ('compra',?,?,?,?,?)",
      [compraId, comp.nick, comp.coins, comp.vip_nivel, comp.vip_dias]);
    await c.execute('INSERT INTO ucp_transacoes (nick,tipo,descricao,coins,valor_centavos,ref) VALUES (?,?,?,?,?,?)',
      [comp.nick, comp.tipo === 'coins' ? 'recarga' : 'compra', comp.produto_nome, comp.coins, comp.valor_centavos, compraId]);
    return { entregaId: ins.insertId, comp };
  });
  if (r.jaProcessada) return { ok: true, duplicada: true };
  bridge.enviarEntrega(r.comp.nick, { coins: r.comp.coins, vipNivel: r.comp.vip_nivel, vipDias: r.comp.vip_dias, id: r.entregaId });
  await db.query("UPDATE ucp_entregas SET status='enviada' WHERE id=?", [r.entregaId]);
  await audit.log(ator || 'gateway', 'pagamento.aprovado', compraId, ip);
  return { ok: true };
}

// Chamado periodicamente: confirmacoes gravadas pela GameMode viram "entregue".
async function sincronizarConfirmacoes() {
  // reenvia entregas que ficaram pendentes (ex.: falha ao gravar arquivo apos o commit)
  const pend = await db.query("SELECT id, nick, coins, vip_nivel, vip_dias FROM ucp_entregas WHERE status='pendente' AND criado_em < DATE_SUB(NOW(), INTERVAL 1 MINUTE)");
  for (const e of pend) {
    try { bridge.enviarEntrega(e.nick, { coins: e.coins, vipNivel: e.vip_nivel, vipDias: e.vip_dias, id: e.id }); await db.query("UPDATE ucp_entregas SET status='enviada' WHERE id=?", [e.id]); }
    catch (err) { console.error('[entrega]', e.id, err.message); }
  }
  const ids = bridge.lerConfirmacoes();
  for (const id of ids) {
    await db.query("UPDATE ucp_entregas SET status='entregue', entregue_em=NOW() WHERE id=? AND status<>'entregue'", [id]);
    await db.query("UPDATE ucp_compras c JOIN ucp_entregas e ON e.compra_id=c.id SET c.status='entregue', c.entregue_em=NOW() WHERE e.id=? AND c.status='pago'", [id]);
  }
  return ids.length;
}
module.exports = { criarCompra, aprovar, sincronizarConfirmacoes };
