// Ponte com a GameMode via scriptfiles/UCP/* (a GameMode grava; o UCP le).
const fs = require('fs');
const { cfg } = require('../config/env');
const ini = require('./ini');
const roles = require('../config/roles');

const dir = (...p) => cfg.scriptfiles ? ini.safeJoin(cfg.scriptfiles, 'UCP', ...p) : null;
const ONLINE_MS = 90 * 1000;
const cache = new Map();

function statusPath(nick) { return dir('Status', nick + '.ini'); }

function getStatus(nick) {
  if (!cfg.scriptfiles || !ini.NICK_RE.test(nick)) return null;
  const hit = cache.get(nick);
  if (hit && Date.now() - hit.t < 5000) return hit.v;
  const raw = ini.readFile(statusPath(nick));
  let v = null;
  if (raw) {
    const atualizado = ini.int(raw.Atualizado) * 1000;
    v = {
      nick: raw.Nick || nick, idConta: ini.int(raw.IDConta), level: ini.int(raw.Level), admin: ini.int(raw.Admin),
      dinheiro: ini.int(raw.Dinheiro), banco: ini.int(raw.Banco), coins: ini.int(raw.Coins),
      vip: ini.int(raw.VIP), socio: ini.int(raw.Socio), diaVip: ini.int(raw.DiaVIP),
      organizacao: raw.Organizacao || 'Nenhuma', membro: ini.int(raw.Membro), lider: ini.int(raw.Lider), cargo: ini.int(raw.Cargo),
      emprego: raw.Emprego || 'Desempregado', horas: ini.int(raw.Horas), ultimoLogin: raw.UltimoLogin || '-',
      registro: raw.Registro || '-', atualizado, online: Date.now() - atualizado < ONLINE_MS,
      adminRank: roles.rankName(ini.int(raw.Admin)), cargoUcp: roles.cargoFromAdmin(ini.int(raw.Admin))
    };
  }
  cache.set(nick, { t: Date.now(), v });
  return v;
}

function listStatus() {
  if (!cfg.scriptfiles) return [];
  let files = [];
  try { files = fs.readdirSync(dir('Status')); } catch (e) { return []; }
  const out = [];
  for (const f of files) {
    if (!f.endsWith('.ini')) continue;
    const s = getStatus(f.slice(0, -4));
    if (s) out.push(s);
  }
  return out;
}

// Consome um codigo gerado por /vincularucp. Retorna {nick, idConta, admin} ou lanca erro.
function consumirCodigo(code, nick) {
  if (!cfg.scriptfiles) throw new Error('Vinculacao antiga do jogo indisponivel. Use o cadastro com Discord.');
  if (!ini.CODE_RE.test(code || '')) throw new Error('Codigo invalido.');
  const f = dir('Vinculos', code + '.ini');
  const raw = ini.readFile(f);
  if (!raw) throw new Error('Codigo inexistente, expirado ou ja utilizado. Gere outro com /vincularucp no jogo.');
  const expira = ini.int(raw.Expira);
  const ok = raw.Nick && raw.Nick.toLowerCase() === String(nick).toLowerCase();
  if (!ok) throw new Error('Este codigo pertence a outro jogador.');
  fs.unlinkSync(f); // uso unico
  if (expira < Math.floor(Date.now() / 1000)) throw new Error('Codigo expirado. Gere outro com /vincularucp no jogo.');
  return { nick: raw.Nick, idConta: ini.int(raw.IDConta), admin: ini.int(raw.Admin) };
}

function limparCodigosExpirados() {
  if (!cfg.scriptfiles) return;
  let files = [];
  try { files = fs.readdirSync(dir('Vinculos')); } catch (e) { return; }
  const now = Math.floor(Date.now() / 1000);
  for (const f of files) {
    if (!f.endsWith('.ini')) continue;
    try { const raw = ini.readFile(dir('Vinculos', f)); if (!raw || ini.int(raw.Expira) < now) fs.unlinkSync(dir('Vinculos', f)); } catch (e) { /* ignora */ }
  }
}

// Escreve/mescla a entrega para o jogador (a GameMode aplica e apaga o arquivo).
function enviarEntrega(nick, { coins = 0, vipNivel = 0, vipDias = 0, id }) {
  if (!cfg.scriptfiles) throw new Error('Entrega no jogo indisponivel: configure SAMP_SCRIPTFILES no backend.');
  if (!ini.NICK_RE.test(nick)) throw new Error('nick invalido');
  const f = dir('Entregas', nick + '.ini');
  const cur = ini.readFile(f) || {};
  const out = {
    Coins: ini.int(cur.Coins) + coins,
    VIPNivel: ini.int(cur.VIPNivel), VIPDias: ini.int(cur.VIPDias),
    Ids: cur.Ids ? cur.Ids + ',' + id : String(id)
  };
  if (vipNivel > 0 && vipDias > 0) {
    if (out.VIPNivel === vipNivel) out.VIPDias += vipDias;
    else if (vipNivel > out.VIPNivel) { out.VIPNivel = vipNivel; out.VIPDias = vipDias; }
    else out.VIPDias += 0;
  }
  ini.writeFile(f, out);
}

// Le confirmacoes gravadas pela GameMode e devolve a lista de ids de entrega aplicados.
function lerConfirmacoes() {
  if (!cfg.scriptfiles) return [];
  let files = [];
  try { files = fs.readdirSync(dir('Confirmacoes')); } catch (e) { return []; }
  const ids = [];
  for (const f of files) {
    if (!f.endsWith('.ini')) continue;
    const p = dir('Confirmacoes', f);
    const raw = ini.readFile(p);
    if (!raw) continue;
    for (const x of (raw.Ids || '').split(',')) { const n = ini.int(x, 0); if (n > 0) ids.push(n); }
    try { fs.unlinkSync(p); } catch (e) { /* ignora */ }
  }
  return ids;
}

module.exports = { getStatus, listStatus, consumirCodigo, limparCodigosExpirados, enviarEntrega, lerConfirmacoes };
