const db = require('../config/db');
async function log(ator, acao, detalhe, ip) {
  try { await db.query('INSERT INTO ucp_logs (ator, acao, detalhe, ip) VALUES (?,?,?,?)', [ator, acao, detalhe ? String(detalhe).slice(0, 2000) : null, ip || null]); }
  catch (e) { console.error('[audit]', e.message); }
}
module.exports = { log };
