const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { cfg } = require('../config/env');
const db = require('../config/db');
fs.mkdirSync(cfg.uploadDir, { recursive: true });
const TIPOS = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' };
const storage = multer.diskStorage({
  destination: cfg.uploadDir,
  filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + (TIPOS[file.mimetype] || '.bin'))
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024, files: 5 },
  fileFilter: (req, file, cb) => TIPOS[file.mimetype] ? cb(null, true) : cb(new Error('Somente imagens JPG, PNG, WEBP ou GIF de ate 5MB.')) });
// Confere assinatura real do arquivo (nao confia so no mimetype enviado pelo navegador)
function assinaturaOk(file) {
  const b = Buffer.alloc(12); const fd = fs.openSync(file.path, 'r'); fs.readSync(fd, b, 0, 12, 0); fs.closeSync(fd);
  if (file.mimetype === 'image/jpeg') return b[0] === 0xFF && b[1] === 0xD8;
  if (file.mimetype === 'image/png') return b.slice(0, 4).toString('hex') === '89504e47';
  if (file.mimetype === 'image/gif') return b.slice(0, 3).toString() === 'GIF';
  if (file.mimetype === 'image/webp') return b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP';
  return false;
}
async function registrar(files, dono) {
  const ids = [];
  for (const f of files || []) {
    if (!assinaturaOk(f)) { try { fs.unlinkSync(f.path); } catch (e) { /* ok */ } continue; }
    const r = await db.query('INSERT INTO ucp_arquivos (nome_original, nome_disco, mime, tamanho, dono) VALUES (?,?,?,?,?)',
      [path.basename(f.originalname).slice(0, 200), f.filename, f.mimetype, f.size, dono]);
    ids.push(r.insertId);
  }
  return ids;
}
module.exports = { upload, registrar };
