const express = require('express');
const db = require('../config/db');
const audit = require('../services/audit');
const { upload, registrar } = require('../services/upload');
const { exigirLogin } = require('../middleware/auth');
const r = express.Router();
r.use(exigirLogin);
const CATS = ['suporte', 'conta', 'compras', 'denuncias', 'bugs', 'outros'];
const staff = (req) => req.user.permissoes.includes('tickets.responder');

r.get('/', async (req, res, next) => {
  try { res.json({ tickets: await db.query('SELECT id,categoria,assunto,status,criado_em,atualizado_em FROM ucp_tickets WHERE nick=? ORDER BY atualizado_em DESC LIMIT 100', [req.user.nick]) }); } catch (e) { next(e); }
});
r.post('/', upload.array('anexos', 3), async (req, res, next) => {
  try {
    const { categoria, assunto, mensagem } = req.body || {};
    if (!CATS.includes(categoria)) return res.status(400).json({ erro: 'Categoria invalida.' });
    if (!assunto || assunto.length < 4 || assunto.length > 150) return res.status(400).json({ erro: 'Assunto deve ter de 4 a 150 caracteres.' });
    if (!mensagem || mensagem.length < 10 || mensagem.length > 4000) return res.status(400).json({ erro: 'Mensagem deve ter de 10 a 4000 caracteres.' });
    const t = await db.query('INSERT INTO ucp_tickets (nick,categoria,assunto) VALUES (?,?,?)', [req.user.nick, categoria, assunto]);
    const arqs = await registrar(req.files, req.user.nick);
    await db.query('INSERT INTO ucp_ticket_messages (ticket_id,autor,staff,mensagem,arquivo_id) VALUES (?,?,0,?,?)', [t.insertId, req.user.nick, mensagem, arqs[0] || null]);
    await audit.log(req.user.nick, 'ticket.abrir', '#' + t.insertId, req.ip);
    res.json({ ok: true, id: t.insertId });
  } catch (e) { next(e); }
});
r.get('/:id', async (req, res, next) => {
  try {
    const t = await db.one('SELECT * FROM ucp_tickets WHERE id=?', [req.params.id]);
    if (!t || (t.nick !== req.user.nick && !staff(req))) return res.status(404).json({ erro: 'Ticket nao encontrado.' });
    const msgs = await db.query('SELECT id,autor,staff,mensagem,arquivo_id,criado_em FROM ucp_ticket_messages WHERE ticket_id=? ORDER BY id', [t.id]);
    res.json({ ticket: t, mensagens: msgs });
  } catch (e) { next(e); }
});
r.post('/:id/mensagens', upload.array('anexos', 3), async (req, res, next) => {
  try {
    const t = await db.one('SELECT * FROM ucp_tickets WHERE id=?', [req.params.id]);
    const ehStaff = staff(req);
    if (!t || (t.nick !== req.user.nick && !ehStaff)) return res.status(404).json({ erro: 'Ticket nao encontrado.' });
    if (t.status === 'fechado') return res.status(400).json({ erro: 'Ticket fechado.' });
    const m = (req.body || {}).mensagem;
    if (!m || m.length < 2 || m.length > 4000) return res.status(400).json({ erro: 'Mensagem invalida.' });
    const arqs = await registrar(req.files, req.user.nick);
    const souEquipe = ehStaff && t.nick !== req.user.nick ? 1 : 0;
    await db.query('INSERT INTO ucp_ticket_messages (ticket_id,autor,staff,mensagem,arquivo_id) VALUES (?,?,?,?,?)', [t.id, req.user.nick, souEquipe, m, arqs[0] || null]);
    await db.query('UPDATE ucp_tickets SET status=?, atualizado_em=NOW() WHERE id=?', [souEquipe ? 'respondido' : 'aberto', t.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
r.post('/:id/fechar', async (req, res, next) => {
  try {
    const t = await db.one('SELECT * FROM ucp_tickets WHERE id=?', [req.params.id]);
    if (!t || (t.nick !== req.user.nick && !staff(req))) return res.status(404).json({ erro: 'Ticket nao encontrado.' });
    await db.query("UPDATE ucp_tickets SET status='fechado', atualizado_em=NOW() WHERE id=?", [t.id]);
    await audit.log(req.user.nick, 'ticket.fechar', '#' + t.id, req.ip);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
module.exports = r;
