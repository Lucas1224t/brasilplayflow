const express = require('express');
const db = require('../config/db');
const ini = require('../services/ini');
const bridge = require('../services/bridge');
const audit = require('../services/audit');
const pagamentos = require('../services/pagamentos');
const roles = require('../config/roles');
const { exigirStaff, exigirPermissao } = require('../middleware/auth');
const r = express.Router();
r.use(exigirStaff);

r.get('/resumo', async (req, res, next) => {
  try {
    res.json({ cargo: req.user.cargo, permissoes: req.user.permissoes,
      tickets: (await db.one("SELECT COUNT(*) n FROM ucp_tickets WHERE status<>'fechado'")).n,
      denuncias: (await db.one("SELECT COUNT(*) n FROM ucp_denuncias WHERE status IN ('aguardando','analise')")).n,
      jogadores: bridge.listStatus().length, online: bridge.listStatus().filter((s) => s.online).length });
  } catch (e) { next(e); }
});
r.get('/jogadores', exigirPermissao('players.ver'), async (req, res, next) => {
  try {
    const q = String(req.query.q || '').toLowerCase().trim();
    const lista = bridge.listStatus().filter((s) => !q || s.nick.toLowerCase().includes(q) || String(s.idConta) === q).slice(0, 100);
    const vinc = await db.query('SELECT nick FROM ucp_contas');
    const set = new Set(vinc.map((v) => v.nick.toLowerCase()));
    res.json({ jogadores: lista.map((s) => ({ ...s, vinculado: set.has(s.nick.toLowerCase()) })) });
  } catch (e) { next(e); }
});
// ---- denuncias
r.get('/denuncias', exigirPermissao('denuncias.gerenciar'), async (req, res, next) => {
  try {
    const st = ['aguardando', 'analise', 'aceita', 'recusada', 'finalizada'].includes(req.query.status) ? req.query.status : null;
    res.json({ denuncias: await db.query('SELECT id,autor,denunciado,motivo,status,responsavel,criado_em FROM ucp_denuncias' + (st ? ' WHERE status=?' : '') + ' ORDER BY id DESC LIMIT 100', st ? [st] : []) });
  } catch (e) { next(e); }
});
r.post('/denuncias/:id/status', exigirPermissao('denuncias.gerenciar'), async (req, res, next) => {
  try {
    const s = (req.body || {}).status;
    if (!['analise', 'aceita', 'recusada', 'finalizada'].includes(s)) return res.status(400).json({ erro: 'Status invalido.' });
    await db.query('UPDATE ucp_denuncias SET status=?, responsavel=?, atualizado_em=NOW() WHERE id=?', [s, req.user.nick, req.params.id]);
    await audit.log(req.user.nick, 'denuncia.status', '#' + req.params.id + ' -> ' + s, req.ip);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
// ---- tickets
r.get('/tickets', exigirPermissao('tickets.responder'), async (req, res, next) => {
  try {
    const st = ['aberto', 'respondido', 'fechado'].includes(req.query.status) ? req.query.status : null;
    res.json({ tickets: await db.query('SELECT id,nick,categoria,assunto,status,atualizado_em FROM ucp_tickets' + (st ? ' WHERE status=?' : '') + ' ORDER BY atualizado_em DESC LIMIT 100', st ? [st] : []) });
  } catch (e) { next(e); }
});
// ---- noticias
const TIPOS = ['noticia', 'atualizacao', 'evento', 'manutencao', 'comunicado'];
r.get('/noticias', exigirPermissao('noticias.editar'), async (req, res, next) => {
  try { res.json({ noticias: await db.query('SELECT * FROM ucp_noticias ORDER BY criado_em DESC LIMIT 100') }); } catch (e) { next(e); }
});
r.post('/noticias', exigirPermissao('noticias.editar'), async (req, res, next) => {
  try {
    const { id, tipo, titulo, corpo, publicado } = req.body || {};
    if (!TIPOS.includes(tipo) || !titulo || titulo.length > 150 || !corpo || corpo.length > 10000) return res.status(400).json({ erro: 'Dados invalidos.' });
    if (id) {
      await db.query('UPDATE ucp_noticias SET tipo=?, titulo=?, corpo=?, publicado=?, editado_em=NOW() WHERE id=?', [tipo, titulo, corpo, publicado ? 1 : 0, id]);
      await audit.log(req.user.nick, 'noticia.editar', '#' + id, req.ip);
    } else {
      const n = await db.query('INSERT INTO ucp_noticias (tipo,titulo,corpo,autor,publicado) VALUES (?,?,?,?,?)', [tipo, titulo, corpo, req.user.nick, publicado === false ? 0 : 1]);
      await audit.log(req.user.nick, 'noticia.criar', '#' + n.insertId, req.ip);
    }
    res.json({ ok: true });
  } catch (e) { next(e); }
});
r.delete('/noticias/:id', exigirPermissao('noticias.editar'), async (req, res, next) => {
  try { await db.query('DELETE FROM ucp_noticias WHERE id=?', [req.params.id]); await audit.log(req.user.nick, 'noticia.excluir', '#' + req.params.id, req.ip); res.json({ ok: true }); } catch (e) { next(e); }
});
// ---- produtos
r.get('/produtos', exigirPermissao('produtos.gerenciar'), async (req, res, next) => {
  try { res.json({ produtos: await db.query('SELECT * FROM ucp_produtos ORDER BY ordem,id') }); } catch (e) { next(e); }
});
r.post('/produtos', exigirPermissao('produtos.gerenciar'), async (req, res, next) => {
  try {
    const b = req.body || {};
    const tipo = b.tipo; const preco = parseInt(b.preco_centavos, 10);
    const coins = parseInt(b.coins || 0, 10), nivel = parseInt(b.vip_nivel || 0, 10), dias = parseInt(b.vip_dias || 0, 10);
    if (!b.nome || b.nome.length > 80 || !['coins', 'vip'].includes(tipo) || !(preco > 0) || preco > 100000000) return res.status(400).json({ erro: 'Dados invalidos.' });
    if (tipo === 'coins' && !(coins > 0)) return res.status(400).json({ erro: 'Informe a quantidade de moedas.' });
    if (tipo === 'vip' && !([1, 2].includes(nivel) && dias > 0 && dias <= 365)) return res.status(400).json({ erro: 'VIP: nivel 1 (Comum) ou 2 (Premium) e dias de 1 a 365.' });
    const v = [b.nome, b.descricao || null, tipo, tipo === 'coins' ? coins : 0, tipo === 'vip' ? nivel : 0, tipo === 'vip' ? dias : 0, preco, b.ativo === false ? 0 : 1, parseInt(b.ordem || 0, 10)];
    if (b.id) await db.query('UPDATE ucp_produtos SET nome=?,descricao=?,tipo=?,coins=?,vip_nivel=?,vip_dias=?,preco_centavos=?,ativo=?,ordem=? WHERE id=?', [...v, b.id]);
    else await db.query('INSERT INTO ucp_produtos (nome,descricao,tipo,coins,vip_nivel,vip_dias,preco_centavos,ativo,ordem) VALUES (?,?,?,?,?,?,?,?,?)', v);
    await audit.log(req.user.nick, 'produto.salvar', b.nome + ' R$' + (preco / 100).toFixed(2), req.ip);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
// ---- compras e pagamentos
r.get('/compras', exigirPermissao('compras.ver'), async (req, res, next) => {
  try { res.json({ compras: await db.query('SELECT id,nick,produto_nome,valor_centavos,status,criado_em,pago_em,entregue_em FROM ucp_compras ORDER BY criado_em DESC LIMIT 200') }); } catch (e) { next(e); }
});
r.get('/pagamentos', exigirPermissao('pagamentos.ver'), async (req, res, next) => {
  try { res.json({ pagamentos: await db.query('SELECT id,compra_id,gateway,gateway_id,valor_centavos,status,criado_em,aprovado_em FROM ucp_pagamentos ORDER BY id DESC LIMIT 200') }); } catch (e) { next(e); }
});
// Confirmacao manual (somente gateway "manual"): conferida pela equipe, auditada, idempotente.
r.post('/pagamentos/:compraId/confirmar', exigirPermissao('pagamentos.confirmar'), async (req, res, next) => {
  try {
    const p = await db.one('SELECT gateway FROM ucp_pagamentos WHERE compra_id=?', [req.params.compraId]);
    if (!p) return res.status(404).json({ erro: 'Pagamento nao encontrado.' });
    if (p.gateway !== 'manual') return res.status(400).json({ erro: 'Pagamentos de gateway so sao confirmados pelo proprio gateway.' });
    res.json(await pagamentos.aprovar(req.params.compraId, null, req.user.nick, req.ip));
  } catch (e) { next(e); }
});
// ---- moedas VIP (ajuste com auditoria; aplicado no jogo pela mesma fila de entregas)
r.post('/moedas', exigirPermissao('moedas.ajustar'), async (req, res, next) => {
  try {
    const { nick, quantidade, motivo } = req.body || {};
    const q = parseInt(quantidade, 10);
    if (!ini.NICK_RE.test(String(nick || '')) || !Number.isInteger(q) || q === 0 || Math.abs(q) > 100000) return res.status(400).json({ erro: 'Dados invalidos (quantidade diferente de 0, ate 100000).' });
    if (!motivo || motivo.length < 5) return res.status(400).json({ erro: 'Informe o motivo (auditoria).' });
    if (!bridge.getStatus(nick)) return res.status(404).json({ erro: 'Jogador nao encontrado.' });
    const e = await db.query("INSERT INTO ucp_entregas (origem,nick,coins) VALUES ('ajuste',?,?)", [nick, q]);
    await db.query("INSERT INTO ucp_transacoes (nick,tipo,descricao,coins) VALUES (?, 'ajuste', ?, ?)", [nick, 'Ajuste da equipe: ' + motivo.slice(0, 150), q]);
    bridge.enviarEntrega(nick, { coins: q, id: e.insertId });
    await db.query("UPDATE ucp_entregas SET status='enviada' WHERE id=?", [e.insertId]);
    await audit.log(req.user.nick, 'moedas.ajuste', nick + ' ' + q + ' | ' + motivo, req.ip);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
// ---- logs
r.get('/logs', exigirPermissao('logs.ver'), async (req, res, next) => {
  try {
    const q = String(req.query.q || '').slice(0, 40);
    res.json({ logs: await db.query('SELECT ator,acao,detalhe,ip,criado_em FROM ucp_logs' + (q ? ' WHERE ator LIKE ? OR acao LIKE ?' : '') + ' ORDER BY id DESC LIMIT 200', q ? ['%' + q + '%', '%' + q + '%'] : []) });
  } catch (e) { next(e); }
});
// ---- cargos e permissoes
r.get('/cargos', exigirPermissao('permissoes.gerenciar'), async (req, res, next) => {
  try {
    const cargos = (await db.query('SELECT cargo, permissoes FROM ucp_cargos')).map((c) => ({ cargo: c.cargo, permissoes: JSON.parse(c.permissoes) }));
    res.json({ cargos, permissoesDisponiveis: roles.PERMISSOES, overrides: await db.query('SELECT nick,cargo,extras,bloqueado FROM ucp_permissoes') });
  } catch (e) { next(e); }
});
r.post('/cargos', exigirPermissao('permissoes.gerenciar'), async (req, res, next) => {
  try {
    const { cargo, permissoes } = req.body || {};
    if (!roles.PADRAO[cargo] || !Array.isArray(permissoes) || permissoes.some((p) => !roles.PERMISSOES.includes(p))) return res.status(400).json({ erro: 'Dados invalidos.' });
    if (cargo === 'Dono' && !permissoes.includes('permissoes.gerenciar')) return res.status(400).json({ erro: 'O cargo Dono precisa manter permissoes.gerenciar.' });
    await db.query('INSERT INTO ucp_cargos (cargo, permissoes) VALUES (?,?) ON DUPLICATE KEY UPDATE permissoes=VALUES(permissoes)', [cargo, JSON.stringify(permissoes)]);
    await audit.log(req.user.nick, 'cargo.permissoes', cargo + ': ' + permissoes.join(','), req.ip);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
r.post('/funcionario', exigirPermissao('permissoes.gerenciar'), async (req, res, next) => {
  try {
    const { nick, cargo, bloqueado } = req.body || {};
    if (!ini.NICK_RE.test(String(nick || '')) || (cargo && !roles.PADRAO[cargo])) return res.status(400).json({ erro: 'Dados invalidos.' });
    await db.query('INSERT INTO ucp_permissoes (nick,cargo,bloqueado) VALUES (?,?,?) ON DUPLICATE KEY UPDATE cargo=VALUES(cargo), bloqueado=VALUES(bloqueado)', [nick, cargo || null, bloqueado ? 1 : 0]);
    if (bloqueado) await db.query('DELETE FROM ucp_sessions WHERE nick=?', [nick]);
    await audit.log(req.user.nick, 'funcionario.salvar', nick + ' cargo=' + (cargo || '-') + ' bloqueado=' + (bloqueado ? 1 : 0), req.ip);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
module.exports = r;
