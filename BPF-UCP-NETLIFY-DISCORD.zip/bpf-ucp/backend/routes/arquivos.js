const express = require('express');
const path = require('path');
const db = require('../config/db');
const { cfg } = require('../config/env');
const { exigirLogin } = require('../middleware/auth');
const r = express.Router();
// Anexos so sao servidos ao dono ou a equipe; nunca por pasta publica.
r.get('/:id', exigirLogin, async (req, res, next) => {
  try {
    const a = await db.one('SELECT * FROM ucp_arquivos WHERE id=?', [req.params.id]);
    if (!a) return res.status(404).end();
    const staff = req.user.permissoes.includes('denuncias.gerenciar') || req.user.permissoes.includes('tickets.responder');
    if (a.dono !== req.user.nick && !staff) return res.status(404).end();
    res.setHeader('Content-Type', a.mime); res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Disposition', 'inline; filename="anexo' + path.extname(a.nome_disco) + '"');
    res.sendFile(path.join(cfg.uploadDir, a.nome_disco));
  } catch (e) { next(e); }
});
module.exports = r;
