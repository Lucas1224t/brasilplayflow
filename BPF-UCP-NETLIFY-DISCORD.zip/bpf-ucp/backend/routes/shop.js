const express = require('express');
const db = require('../config/db');
const bridge = require('../services/bridge');
const pagamentos = require('../services/pagamentos');
const rateLimit = require('express-rate-limit');
const { exigirLogin } = require('../middleware/auth');
const r = express.Router();
r.use(exigirLogin);
const limite = rateLimit({ windowMs: 10 * 60 * 1000, max: 15, message: { erro: 'Muitas compras iniciadas. Aguarde.' } });

r.get('/produtos', async (req, res, next) => {
  try { res.json({ produtos: await db.query('SELECT id,nome,descricao,tipo,coins,vip_nivel,vip_dias,preco_centavos FROM ucp_produtos WHERE ativo=1 ORDER BY ordem,id') }); } catch (e) { next(e); }
});
r.post('/comprar', limite, async (req, res, next) => {
  try {
    const id = parseInt((req.body || {}).produto_id, 10); // so o ID vem do navegador; preco e entrega vem do banco
    if (!Number.isInteger(id)) return res.status(400).json({ erro: 'Produto invalido.' });
    const abertas = await db.one("SELECT COUNT(*) n FROM ucp_compras WHERE nick=? AND status='pendente' AND criado_em > DATE_SUB(NOW(), INTERVAL 1 HOUR)", [req.user.nick]);
    if (abertas.n >= 3) return res.status(429).json({ erro: 'Voce ja tem 3 compras aguardando pagamento.' });
    res.json({ ok: true, ...(await pagamentos.criarCompra(req.user.nick, id, null, req.ip)) });
  } catch (e) { if (/indisponivel/.test(e.message)) return res.status(400).json({ erro: e.message }); next(e); }
});
r.get('/compras', async (req, res, next) => {
  try {
    res.json({ compras: await db.query(`SELECT c.id,c.produto_nome,c.valor_centavos,c.status,c.criado_em,c.pago_em,c.entregue_em,p.pix_copia_cola,p.gateway
      FROM ucp_compras c LEFT JOIN ucp_pagamentos p ON p.compra_id=c.id WHERE c.nick=? ORDER BY c.criado_em DESC LIMIT 100`, [req.user.nick]) });
  } catch (e) { next(e); }
});
r.get('/entregas', async (req, res, next) => {
  try { res.json({ entregas: await db.query('SELECT id,origem,coins,vip_nivel,vip_dias,status,criado_em,entregue_em FROM ucp_entregas WHERE nick=? ORDER BY id DESC LIMIT 100', [req.user.nick]) }); } catch (e) { next(e); }
});
r.get('/moedas', async (req, res, next) => {
  try {
    const st = bridge.getStatus(req.user.nick);
    res.json({ saldo: st ? st.coins : null, atualizadoEm: st ? st.atualizado : null,
      recargas: await db.query("SELECT descricao,coins,valor_centavos,criado_em FROM ucp_transacoes WHERE nick=? AND tipo='recarga' ORDER BY id DESC LIMIT 100", [req.user.nick]),
      ajustes: await db.query("SELECT descricao,coins,criado_em FROM ucp_transacoes WHERE nick=? AND tipo='ajuste' ORDER BY id DESC LIMIT 100", [req.user.nick]) });
  } catch (e) { next(e); }
});
module.exports = r;
