const express = require('express');
const db = require('../config/db');
const ini = require('../services/ini');
const audit = require('../services/audit');
const bridge = require('../services/bridge');
const { upload, registrar } = require('../services/upload');
const { exigirLogin } = require('../middleware/auth');
const r = express.Router();
r.use(exigirLogin);
const staff = (req) => req.user.permissoes.includes('denuncias.gerenciar');

r.get('/', async (req, res, next) => {
  try { res.json({ denuncias: await db.query('SELECT id,denunciado,motivo,status,criado_em,atualizado_em FROM ucp_denuncias WHERE autor=? ORDER BY id DESC LIMIT 100', [req.user.nick]) }); } catch (e) { next(e); }
});
r.post('/', upload.array('provas', 5), async (req, res, next) => {
  try {
    const { denunciado, motivo, descricao } = req.body || {};
    if (!ini.NICK_RE.test(String(denunciado || ''))) return res.status(400).json({ erro: 'Nick do denunciado invalido.' });
    if (denunciado.toLowerCase() === req.user.nick.toLowerCase()) return res.status(400).json({ erro: 'Voce nao pode denunciar a si mesmo.' });
    if (!bridge.getStatus(denunciado)) return res.status(400).json({ erro: 'Jogador nao encontrado no servidor (ele precisa ter jogado desde a instalacao do UCP).' });
    if (!motivo || motivo.length < 3 || motivo.length > 100) return res.status(400).json({ erro: 'Informe o motivo (ate 100 caracteres).' });
    if (!descricao || descricao.length < 20 || descricao.length > 4000) return res.status(400).json({ erro: 'Descreva o ocorrido (minimo 20 caracteres).' });
    const rec = await db.one("SELECT COUNT(*) n FROM ucp_denuncias WHERE autor=? AND criado_em > DATE_SUB(NOW(), INTERVAL 1 HOUR)", [req.user.nick]);
    if (rec.n >= 5) return res.status(429).json({ erro: 'Limite de 5 denuncias por hora.' });
    const d = await db.query('INSERT INTO ucp_denuncias (autor,denunciado,motivo,descricao) VALUES (?,?,?,?)', [req.user.nick, denunciado, motivo, descricao]);
    for (const id of await registrar(req.files, req.user.nick)) await db.query('INSERT INTO ucp_denuncia_provas (denuncia_id, arquivo_id) VALUES (?,?)', [d.insertId, id]);
    await audit.log(req.user.nick, 'denuncia.abrir', '#' + d.insertId + ' contra ' + denunciado, req.ip);
    res.json({ ok: true, id: d.insertId });
  } catch (e) { next(e); }
});
r.get('/:id', async (req, res, next) => {
  try {
    const d = await db.one('SELECT * FROM ucp_denuncias WHERE id=?', [req.params.id]);
    if (!d || (d.autor !== req.user.nick && !staff(req))) return res.status(404).json({ erro: 'Denuncia nao encontrada.' });
    res.json({ denuncia: d,
      provas: await db.query('SELECT arquivo_id FROM ucp_denuncia_provas WHERE denuncia_id=?', [d.id]),
      mensagens: await db.query('SELECT autor,staff,mensagem,criado_em FROM ucp_denuncia_msgs WHERE denuncia_id=? ORDER BY id', [d.id]) });
  } catch (e) { next(e); }
});
r.post('/:id/mensagens', async (req, res, next) => {
  try {
    const d = await db.one('SELECT * FROM ucp_denuncias WHERE id=?', [req.params.id]);
    const ehStaff = staff(req);
    if (!d || (d.autor !== req.user.nick && !ehStaff)) return res.status(404).json({ erro: 'Denuncia nao encontrada.' });
    if (['recusada', 'finalizada'].includes(d.status)) return res.status(400).json({ erro: 'Denuncia encerrada.' });
    const m = (req.body || {}).mensagem;
    if (!m || m.length < 2 || m.length > 4000) return res.status(400).json({ erro: 'Mensagem invalida.' });
    await db.query('INSERT INTO ucp_denuncia_msgs (denuncia_id,autor,staff,mensagem) VALUES (?,?,?,?)', [d.id, req.user.nick, ehStaff && d.autor !== req.user.nick ? 1 : 0, m]);
    await db.query('UPDATE ucp_denuncias SET atualizado_em=NOW() WHERE id=?', [d.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
module.exports = r;
