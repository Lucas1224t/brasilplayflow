const express = require('express');
const db = require('../config/db');
const gateways = require('../integrations/gateways');
const pagamentos = require('../services/pagamentos');
const audit = require('../services/audit');
const r = express.Router();

// Mercado Pago envia {type:'payment', data:{id}}. O corpo NAO e confiavel: o pagamento e consultado no gateway.
r.post('/mercadopago', async (req, res) => {
  try {
    const gw = gateways.porNome('mercadopago');
    const gid = String(((req.body || {}).data || {}).id || req.query['data.id'] || req.query.id || '');
    if (!/^\d{3,20}$/.test(gid)) return res.status(200).json({ ignorado: true });
    const pag = await db.one('SELECT compra_id, valor_centavos FROM ucp_pagamentos WHERE gateway_id=?', [gid]);
    if (!pag) return res.status(200).json({ ignorado: true });
    const info = await gw.consultar(gid);
    if (info.compraId !== pag.compra_id) { await audit.log('gateway', 'webhook.divergente', gid, req.ip); return res.status(200).json({ ignorado: true }); }
    if (info.status === 'aprovado') await pagamentos.aprovar(pag.compra_id, info.valorCentavos, 'gateway', req.ip);
    else if (info.status === 'recusado') { await db.query("UPDATE ucp_pagamentos SET status='recusado' WHERE compra_id=? AND status='pendente'", [pag.compra_id]); await db.query("UPDATE ucp_compras SET status='cancelada' WHERE id=? AND status='pendente'", [pag.compra_id]); }
    res.status(200).json({ ok: true });
  } catch (e) { console.error('[webhook]', e.message); res.status(500).json({ erro: 'falha' }); } // 500 => gateway tenta de novo
});
module.exports = r;
