const express = require('express');
const crypto = require('crypto');
const { cfg } = require('../config/env');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const db = require('../config/db');
const bridge = require('../services/bridge');
const ini = require('../services/ini');
const audit = require('../services/audit');
const { criarSessao, encerrarSessao, exigirLogin } = require('../middleware/auth');

const r = express.Router();
const limite = rateLimit({ windowMs: 15 * 60 * 1000, max: 40, standardHeaders: true, legacyHeaders: false, message: { erro: 'Muitas tentativas. Aguarde alguns minutos.' } });
const SENHA_OK = (s) => typeof s === 'string' && s.length >= 8 && s.length <= 72;
const sha = (v) => crypto.createHash('sha256').update(v).digest('hex');
const NICK_RE = /^[A-Za-z0-9_\[\]\.\$=@()]{3,24}$/;
const discordConfigured = () => !!(cfg.discord.clientId && cfg.discord.clientSecret && cfg.discord.botToken && cfg.discord.guildId && cfg.discord.redirectUri);
const oauthCookie = 'bpf_discord_state';
const frontendLogin = (res, query) => res.redirect('/login.html' + (query ? '?' + query : ''));

r.get('/discord', (req, res) => {
  if (!discordConfigured()) return res.status(503).send('Login Discord ainda nao configurado. Configure as variaveis DISCORD_* no backend.');
  const state = crypto.randomBytes(24).toString('hex');
  res.cookie(oauthCookie, state, { httpOnly: true, sameSite: 'lax', secure: cfg.prod, maxAge: 10 * 60 * 1000, path: '/' });
  const u = new URL('https://discord.com/oauth2/authorize');
  u.search = new URLSearchParams({ client_id: cfg.discord.clientId, redirect_uri: cfg.discord.redirectUri, response_type: 'code', scope: 'identify', state }).toString();
  res.redirect(u.toString());
});

r.get('/discord/callback', async (req, res, next) => {
  try {
    const state = String(req.query.state || '');
    if (!state || !req.cookies[oauthCookie] || state !== req.cookies[oauthCookie] || !req.query.code) return frontendLogin(res, 'erro=discord_state');
    res.clearCookie(oauthCookie, { path: '/' });
    const tokenResponse = await fetch('https://discord.com/api/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: cfg.discord.clientId, client_secret: cfg.discord.clientSecret, grant_type: 'authorization_code', code: String(req.query.code), redirect_uri: cfg.discord.redirectUri }) });
    if (!tokenResponse.ok) return frontendLogin(res, 'erro=discord_oauth');
    const tokenData = await tokenResponse.json();
    const userResponse = await fetch('https://discord.com/api/users/@me', { headers: { Authorization: 'Bearer ' + tokenData.access_token } });
    if (!userResponse.ok) return frontendLogin(res, 'erro=discord_user');
    const discordUser = await userResponse.json();
    const memberResponse = await fetch(`https://discord.com/api/v10/guilds/${encodeURIComponent(cfg.discord.guildId)}/members/${encodeURIComponent(discordUser.id)}`, { headers: { Authorization: 'Bot ' + cfg.discord.botToken } });
    if (memberResponse.status === 404) return frontendLogin(res, 'erro=discord_guild&convite=' + encodeURIComponent(cfg.discord.inviteUrl));
    if (!memberResponse.ok) return frontendLogin(res, 'erro=discord_verify');
    const member = await memberResponse.json();
    const rolesJson = JSON.stringify((member.roles || []).map(String));
    const existing = await db.one('SELECT nick FROM ucp_contas WHERE discord_id=?', [String(discordUser.id)]);
    if (existing) {
      const perm = await db.one('SELECT bloqueado FROM ucp_permissoes WHERE nick=?', [existing.nick]);
      if (perm && perm.bloqueado) return frontendLogin(res, 'erro=blocked');
      await db.query('UPDATE ucp_contas SET discord_username=?, discord_avatar=?, discord_roles=?, ultimo_acesso=NOW(), ultimo_ip=? WHERE nick=?', [discordUser.username, discordUser.avatar || null, rolesJson, req.ip, existing.nick]);
      await db.query('INSERT INTO ucp_acessos (nick, ip, ua, sucesso) VALUES (?,?,?,1)', [existing.nick, req.ip, (req.headers['user-agent'] || '').slice(0,255)]);
      await criarSessao(req, res, existing.nick);
      return res.redirect('/dashboard.html');
    }
    const ticket = crypto.randomBytes(32).toString('hex');
    await db.query('DELETE FROM ucp_discord_pending WHERE discord_id=?', [String(discordUser.id)]);
    await db.query('INSERT INTO ucp_discord_pending (token_hash, discord_id, discord_username, discord_avatar, discord_roles, expira_em) VALUES (?,?,?,?,?,DATE_ADD(NOW(), INTERVAL 10 MINUTE))', [sha(ticket), String(discordUser.id), discordUser.username, discordUser.avatar || null, rolesJson]);
    return frontendLogin(res, 'discord_register=1&ticket=' + encodeURIComponent(ticket));
  } catch (e) { next(e); }
});

r.post('/discord-register', limite, async (req, res, next) => {
  try {
    const { ticket, nick, senha, confirmar } = req.body || {};
    if (!NICK_RE.test(String(nick || ''))) return res.status(400).json({ erro: 'Nick invalido. Use de 3 a 24 caracteres.' });
    if (!SENHA_OK(senha)) return res.status(400).json({ erro: 'A senha deve ter de 8 a 72 caracteres.' });
    if (senha !== confirmar) return res.status(400).json({ erro: 'As senhas nao conferem.' });
    const pending = await db.one('SELECT * FROM ucp_discord_pending WHERE token_hash=? AND expira_em>NOW()', [sha(String(ticket || ''))]);
    if (!pending) return res.status(400).json({ erro: 'A verificacao do Discord expirou. Entre novamente com o Discord.' });
    const dupNick = await db.one('SELECT nick FROM ucp_contas WHERE nick=?', [nick]);
    const dupDiscord = await db.one('SELECT nick FROM ucp_contas WHERE discord_id=?', [pending.discord_id]);
    if (dupNick) return res.status(409).json({ erro: 'Esse Nick ja esta cadastrado.' });
    if (dupDiscord) return res.status(409).json({ erro: 'Esse Discord ja possui uma conta.' });
    const hash = await bcrypt.hash(senha, 12);
    await db.query('INSERT INTO ucp_contas (nick, id_conta, senha_hash, discord_id, discord_username, discord_avatar, discord_roles) VALUES (?,NULL,?,?,?,?,?)', [nick, hash, pending.discord_id, pending.discord_username, pending.discord_avatar, pending.discord_roles]);
    await db.query('DELETE FROM ucp_discord_pending WHERE token_hash=?', [sha(String(ticket))]);
    await audit.log(nick, 'conta.criada_discord', 'Discord ' + pending.discord_id, req.ip);
    await criarSessao(req, res, nick);
    res.json({ ok: true, redirect: '/dashboard.html' });
  } catch (e) { if (e && e.code === 'ER_DUP_ENTRY') return res.status(409).json({ erro: 'Nick ou Discord ja cadastrado.' }); next(e); }
});

async function bloqueado(nick, ip) {
  const a = await db.one("SELECT COUNT(*) n FROM ucp_tentativas WHERE chave=? AND criado_em > DATE_SUB(NOW(), INTERVAL 15 MINUTE)", [nick.toLowerCase()]);
  const b = await db.one("SELECT COUNT(*) n FROM ucp_tentativas WHERE ip=? AND criado_em > DATE_SUB(NOW(), INTERVAL 15 MINUTE)", [ip]);
  return a.n >= 5 || b.n >= 20;
}
const falha = (nick, ip) => db.query('INSERT INTO ucp_tentativas (chave, ip) VALUES (?,?)', [nick.toLowerCase(), ip]);

// Vincula (ou redefine a senha) usando o codigo gerado por /vincularucp dentro do jogo.
r.post('/vincular', limite, async (req, res, next) => {
  try {
    const { nick, codigo, senha } = req.body || {};
    if (!ini.NICK_RE.test(String(nick || ''))) return res.status(400).json({ erro: 'Nick invalido.' });
    if (!SENHA_OK(senha)) return res.status(400).json({ erro: 'A senha do UCP deve ter de 8 a 72 caracteres.' });
    if (await bloqueado(nick, req.ip)) return res.status(429).json({ erro: 'Muitas tentativas. Aguarde 15 minutos.' });
    let v;
    try { v = bridge.consumirCodigo(String(codigo || '').toUpperCase().trim(), nick); }
    catch (e) { await falha(nick, req.ip); return res.status(400).json({ erro: e.message }); }
    const hash = await bcrypt.hash(senha, 12);
    const ex = await db.one('SELECT id, id_conta FROM ucp_contas WHERE nick=?', [v.nick]);
    if (ex) {
      if (ex.id_conta !== v.idConta) return res.status(409).json({ erro: 'Conta do jogo diferente da vinculada. Fale com a equipe.' });
      await db.query('UPDATE ucp_contas SET senha_hash=? WHERE id=?', [hash, ex.id]);
      await audit.log(v.nick, 'conta.senha_redefinida', 'via /vincularucp', req.ip);
    } else {
      await db.query('INSERT INTO ucp_contas (nick, id_conta, senha_hash) VALUES (?,?,?)', [v.nick, v.idConta, hash]);
      await audit.log(v.nick, 'conta.vinculada', 'IDConta ' + v.idConta, req.ip);
    }
    res.json({ ok: true, mensagem: ex ? 'Senha do UCP redefinida. Entre com a nova senha.' : 'Conta vinculada! Agora entre com seu nick e a senha do UCP.' });
  } catch (e) { next(e); }
});

r.post('/login', limite, async (req, res, next) => {
  try {
    const { nick, senha } = req.body || {};
    if (!ini.NICK_RE.test(String(nick || '')) || typeof senha !== 'string') return res.status(400).json({ erro: 'Dados invalidos.' });
    if (await bloqueado(nick, req.ip)) return res.status(429).json({ erro: 'Muitas tentativas. Aguarde 15 minutos.' });
    const c = await db.one('SELECT nick, senha_hash, discord_id FROM ucp_contas WHERE nick=?', [nick]);
    // compara sempre (hash falso) para nao revelar se o nick existe pelo tempo de resposta
    const ok = await bcrypt.compare(senha, c ? c.senha_hash : '$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi');
    const ua = (req.headers['user-agent'] || '').slice(0, 255);
    if (!c || !ok) {
      await falha(nick, req.ip);
      await db.query('INSERT INTO ucp_acessos (nick, ip, ua, sucesso) VALUES (?,?,?,0)', [nick, req.ip, ua]);
      return res.status(401).json({ erro: 'Nick ou senha incorretos. Se sua conta e antiga, solicite a migracao para Discord a equipe.' });
    }
    if (!c.discord_id) return res.status(403).json({ erro: 'Esta conta antiga ainda nao esta vinculada ao Discord. Entre em contato com a equipe para migracao segura.' });
    const memberResponse = await fetch(`https://discord.com/api/v10/guilds/${encodeURIComponent(cfg.discord.guildId)}/members/${encodeURIComponent(c.discord_id)}`, { headers: { Authorization: 'Bot ' + cfg.discord.botToken } });
    if (memberResponse.status === 404) return res.status(403).json({ erro: 'Voce precisa continuar sendo membro do servidor Discord para acessar o UCP.' });
    if (!memberResponse.ok) return res.status(503).json({ erro: 'Nao foi possivel verificar sua participacao no Discord. Tente novamente.' });
    const member = await memberResponse.json();
    await db.query('UPDATE ucp_contas SET discord_roles=? WHERE nick=?', [JSON.stringify((member.roles || []).map(String)), c.nick]);
    const perm = await db.one('SELECT bloqueado FROM ucp_permissoes WHERE nick=?', [c.nick]);
    if (perm && perm.bloqueado) return res.status(403).json({ erro: 'Acesso ao UCP bloqueado.' });
    await db.query('UPDATE ucp_contas SET ultimo_acesso=NOW(), ultimo_ip=? WHERE nick=?', [req.ip, c.nick]);
    await db.query('INSERT INTO ucp_acessos (nick, ip, ua, sucesso) VALUES (?,?,?,1)', [c.nick, req.ip, ua]);
    const csrf = await criarSessao(req, res, c.nick);
    res.json({ ok: true, csrf });
  } catch (e) { next(e); }
});

r.post('/logout', async (req, res, next) => { try { await encerrarSessao(req, res); res.json({ ok: true }); } catch (e) { next(e); } });

r.get('/me', (req, res) => {
  if (!req.user) return res.status(401).json({ erro: 'Nao autenticado.' });
  res.json({ nick: req.user.nick, csrf: req.user.csrf, cargo: req.user.cargo, permissoes: req.user.permissoes, discordId: req.user.discordId, discordUsername: req.user.discordUsername, discordAvatar: req.user.discordAvatar });
});

r.post('/alterar-senha', exigirLogin, limite, async (req, res, next) => {
  try {
    const { atual, nova } = req.body || {};
    if (!SENHA_OK(nova)) return res.status(400).json({ erro: 'A nova senha deve ter de 8 a 72 caracteres.' });
    const c = await db.one('SELECT senha_hash FROM ucp_contas WHERE nick=?', [req.user.nick]);
    if (!c || !(await bcrypt.compare(String(atual || ''), c.senha_hash))) return res.status(401).json({ erro: 'Senha atual incorreta.' });
    await db.query('UPDATE ucp_contas SET senha_hash=? WHERE nick=?', [await bcrypt.hash(nova, 12), req.user.nick]);
    await db.query('DELETE FROM ucp_sessions WHERE nick=? AND csrf<>?', [req.user.nick, req.user.csrf]); // derruba outras sessoes
    await audit.log(req.user.nick, 'conta.senha_alterada', null, req.ip);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
module.exports = r;
