const express = require('express');
const db = require('../config/db');
const { cfg } = require('../config/env');
const samp = require('../integrations/sampQuery');
const bridge = require('../services/bridge');
const roles = require('../config/roles');
const r = express.Router();

let cacheStatus = { t: 0, v: null };
r.get('/status', async (req, res, next) => {
  try {
    if (Date.now() - cacheStatus.t > 10000) { cacheStatus = { t: Date.now(), v: await samp.info(cfg.samp.host, cfg.samp.port) }; }
    const noticias = await db.query("SELECT id,tipo,titulo,LEFT(corpo,240) resumo,autor,criado_em FROM ucp_noticias WHERE publicado=1 ORDER BY criado_em DESC LIMIT 6");
    const produtos = await db.query('SELECT id,nome,descricao,tipo,coins,vip_nivel,vip_dias,preco_centavos FROM ucp_produtos WHERE ativo=1 ORDER BY ordem,id');
    res.json({ servidor: cacheStatus.v, discord: cfg.discord.inviteUrl, noticias, produtos });
  } catch (e) { next(e); }
});
r.get('/equipe', (req, res) => {
  const equipe = bridge.listStatus().filter((s) => s.admin > 0).sort((a, b) => b.admin - a.admin)
    .map((s) => ({ nick: s.nick, cargo: s.adminRank, cargoUcp: roles.cargoFromAdmin(s.admin), online: s.online }));
  res.json({ equipe });
});
r.get('/novidades', async (req, res, next) => {
  try {
    const tipo = ['noticia', 'atualizacao', 'evento', 'manutencao', 'comunicado'].includes(req.query.tipo) ? req.query.tipo : null;
    const rows = await db.query('SELECT id,tipo,titulo,corpo,autor,criado_em FROM ucp_noticias WHERE publicado=1' + (tipo ? ' AND tipo=?' : '') + ' ORDER BY criado_em DESC LIMIT 50', tipo ? [tipo] : []);
    res.json({ novidades: rows });
  } catch (e) { next(e); }
});
module.exports = r;
