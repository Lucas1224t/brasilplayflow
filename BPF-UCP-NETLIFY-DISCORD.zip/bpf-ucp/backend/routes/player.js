const express = require('express');
const db = require('../config/db');
const bridge = require('../services/bridge');
const { exigirLogin } = require('../middleware/auth');
const r = express.Router();
r.use(exigirLogin);

r.get('/painel', async (req, res, next) => {
  try {
    const st = bridge.getStatus(req.user.nick);
    const conta = await db.one('SELECT id, criado_em, ultimo_acesso FROM ucp_contas WHERE nick=?', [req.user.nick]);
    res.json({ nick: req.user.nick, ucpId: conta && conta.id, vinculadoEm: conta && conta.criado_em, cargoUcp: req.user.cargo,
      jogo: st, aviso: st ? null : 'Ainda nao ha dados do jogo. Entre no servidor e aguarde ate 30 segundos.' });
  } catch (e) { next(e); }
});
r.get('/acessos', async (req, res, next) => {
  try { res.json({ acessos: await db.query('SELECT ip, ua, sucesso, criado_em FROM ucp_acessos WHERE nick=? ORDER BY id DESC LIMIT 30', [req.user.nick]) }); } catch (e) { next(e); }
});
r.get('/transacoes', async (req, res, next) => {
  try { res.json({ transacoes: await db.query('SELECT tipo, descricao, coins, valor_centavos, ref, criado_em FROM ucp_transacoes WHERE nick=? ORDER BY id DESC LIMIT 100', [req.user.nick]) }); } catch (e) { next(e); }
});
// A GameMode nao grava historico de punicoes em arquivos; nao ha fonte real, entao a rota informa isso.
r.get('/punicoes', (req, res) => res.json({ punicoes: [], disponivel: false, aviso: 'O historico de punicoes ainda nao e exportado pela GameMode. Veja docs/GAMEMODE.md.' }));
r.get('/ranking', (req, res) => {
  const lista = bridge.listStatus();
  const top = (campo, n = 20) => lista.slice().sort((a, b) => b[campo] - a[campo]).slice(0, n).map((s, i) => ({ pos: i + 1, nick: s.nick, valor: s[campo], org: s.organizacao }));
  const orgs = {};
  for (const s of lista) { if (s.organizacao && s.organizacao !== 'Nenhuma') { const o = orgs[s.organizacao] || (orgs[s.organizacao] = { nome: s.organizacao, membros: 0, level: 0 }); o.membros++; o.level += s.level; } }
  res.json({ niveis: top('level'), horas: top('horas'), dinheiro: lista.slice().sort((a, b) => (b.dinheiro + b.banco) - (a.dinheiro + a.banco)).slice(0, 20).map((s, i) => ({ pos: i + 1, nick: s.nick, valor: s.dinheiro + s.banco, org: s.organizacao })),
    organizacoes: Object.values(orgs).sort((a, b) => b.membros - a.membros).slice(0, 20).map((o, i) => ({ pos: i + 1, ...o })) });
});
r.get('/organizacoes', (req, res) => {
  const lista = bridge.listStatus();
  const orgs = {};
  for (const s of lista) { if (!s.organizacao || s.organizacao === 'Nenhuma') continue; (orgs[s.organizacao] = orgs[s.organizacao] || []).push(s); }
  res.json({ organizacoes: Object.entries(orgs).map(([nome, m]) => ({ nome, total: m.length, membros: m.sort((a, b) => b.lider - a.lider || b.cargo - a.cargo).map((x) => ({ nick: x.nick, cargo: x.cargo, lider: x.lider, level: x.level, online: x.online })) })) });
});
module.exports = r;
