// SOMENTE DESENVOLVIMENTO: cria pastas, produtos de exemplo e a conta de teste Lucas_Fortal (senha do UCP: 223344, guardada com bcrypt).
// Recusa rodar em producao. Nao cria nada na conta real do jogo: grava um "status" de teste na pasta UCP/Status.
const fs = require('fs'); const path = require('path'); const bcrypt = require('bcryptjs');
const { cfg, validate } = require('../config/env'); const db = require('../config/db'); const ini = require('../services/ini');
(async () => {
  if (cfg.prod) { console.error('Recusado: NODE_ENV=production. Este script e apenas para testes.'); process.exit(1); }
  validate();
  for (const d of ['Vinculos', 'Status', 'Entregas', 'Confirmacoes']) fs.mkdirSync(path.join(cfg.scriptfiles, 'UCP', d), { recursive: true });
  const agora = Math.floor(Date.now() / 1000);
  ini.writeFile(path.join(cfg.scriptfiles, 'UCP', 'Status', 'Lucas_Fortal.ini'), { Nick: 'Lucas_Fortal', IDConta: 1, Level: 10, Admin: 1341, Dinheiro: 50000, Banco: 250000, Coins: 100, VIP: 2, Socio: 0, DiaVIP: 15,
    Organizacao: 'Nenhuma', Membro: 0, Lider: 0, Cargo: 0, Emprego: 'Desempregado', Horas: 42, UltimoLogin: '-', Registro: '-', Online: 0, Atualizado: agora });
  await db.query('INSERT INTO ucp_contas (nick,id_conta,senha_hash) VALUES (?,?,?) ON DUPLICATE KEY UPDATE senha_hash=VALUES(senha_hash)', ['Lucas_Fortal', 1, await bcrypt.hash('223344', 12)]);
  const n = (await db.one('SELECT COUNT(*) n FROM ucp_produtos')).n;
  if (!n) {
    const P = [['100 Moedas VIP', 'Pacote inicial', 'coins', 100, 0, 0, 1000], ['500 Moedas VIP', 'Pacote medio', 'coins', 500, 0, 0, 4500], ['1500 Moedas VIP', 'Pacote grande', 'coins', 1500, 0, 0, 12000],
      ['VIP Comum 30 dias', 'VIP nivel 1 da GameMode', 'vip', 0, 1, 30, 1500], ['VIP Premium 30 dias', 'VIP nivel 2 da GameMode', 'vip', 0, 2, 30, 3000]];
    for (const p of P) await db.query('INSERT INTO ucp_produtos (nome,descricao,tipo,coins,vip_nivel,vip_dias,preco_centavos) VALUES (?,?,?,?,?,?,?)', p);
  }
  console.log('Dev pronto. Login de teste: Lucas_Fortal / 223344 (apague com DELETE FROM ucp_contas antes de ir para producao).');
  process.exit(0);
})().catch((e) => { console.error(e.message); process.exit(1); });
