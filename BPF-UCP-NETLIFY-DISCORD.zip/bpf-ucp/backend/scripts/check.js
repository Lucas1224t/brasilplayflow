// Diagnostico: confere .env, banco, pastas do scriptfiles e gateway.
const fs = require('fs'); const path = require('path');
const { cfg, validate } = require('../config/env'); const db = require('../config/db');
(async () => {
  validate(); console.log('[ok] variaveis de ambiente');
  await db.query('SELECT 1'); console.log('[ok] conexao MySQL');
  const t = await db.query("SHOW TABLES LIKE 'ucp_%'"); console.log(`[${t.length >= 18 ? 'ok' : 'ERRO'}] tabelas ucp_* encontradas: ${t.length} (rode npm run db:install)`);
  for (const d of ['Vinculos', 'Status', 'Entregas', 'Confirmacoes']) {
    const p = path.join(cfg.scriptfiles, 'UCP', d);
    try { fs.accessSync(p, fs.constants.R_OK | fs.constants.W_OK); console.log('[ok] pasta', p); } catch (e) { console.log('[ERRO] pasta ausente ou sem permissao:', p); }
  }
  console.log('[info] gateway:', cfg.gateway, cfg.gateway === 'mercadopago' && !cfg.mpToken ? '(sem token!)' : '');
  process.exit(0);
})().catch((e) => { console.error('[ERRO]', e.message); process.exit(1); });
