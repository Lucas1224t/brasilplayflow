// Cria as tabelas ucp_* a partir de database/schema.sql (nao toca em nada da GameMode).
const fs = require('fs'); const path = require('path'); const mysql = require('mysql2/promise');
const { cfg, validate } = require('../config/env');
(async () => {
  validate();
  const c = await mysql.createConnection({ ...cfg.db, multipleStatements: true });
  await c.query(fs.readFileSync(path.resolve(__dirname, '../../database/schema.sql'), 'utf8'));
  console.log('Tabelas do UCP criadas/atualizadas em', cfg.db.database);
  await c.end();
})().catch((e) => { console.error(e.message); process.exit(1); });
