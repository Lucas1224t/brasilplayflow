// Protecao CSRF: toda requisicao que altera dados precisa enviar o token da sessao no cabecalho.
const crypto = require('crypto');
module.exports = function csrf(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.path.startsWith('/webhooks/')) return next(); // webhooks sao validados junto ao gateway
  if (!req.user) return next(); // rotas publicas (login/vincular) tem limite de tentativas proprio
  const h = String(req.headers['x-csrf-token'] || '');
  const a = Buffer.from(h), b = Buffer.from(req.user.csrf);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(403).json({ erro: 'Token CSRF invalido. Recarregue a pagina.' });
  next();
};
