const crypto = require('crypto');
const db = require('../config/db');
const { cfg } = require('../config/env');
const bridge = require('../services/bridge');
const roles = require('../config/roles');

const COOKIE = 'bpf_sid';
const SESSION_H = 12;
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const memberCache = new Map();
async function verificarMembroDiscord(discordId) {
  const hit = memberCache.get(String(discordId));
  if (hit && Date.now() - hit.at < 60000) return hit;
  const response = await fetch(`https://discord.com/api/v10/guilds/${encodeURIComponent(cfg.discord.guildId)}/members/${encodeURIComponent(discordId)}`, { headers: { Authorization: 'Bot ' + cfg.discord.botToken } });
  if (response.status === 404) { const v = { at: Date.now(), missing: true, roles: [] }; memberCache.set(String(discordId), v); return v; }
  if (!response.ok) throw new Error('Falha ao validar membro do Discord (' + response.status + ').');
  const member = await response.json();
  const v = { at: Date.now(), missing: false, roles: (member.roles || []).map(String) };
  memberCache.set(String(discordId), v); return v;
}

async function criarSessao(req, res, nick) {
  const token = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(24).toString('hex');
  await db.query('INSERT INTO ucp_sessions (token_hash, nick, csrf, ip, ua, expira_em) VALUES (?,?,?,?,?, DATE_ADD(NOW(), INTERVAL ? HOUR))',
    [sha(token), nick, csrf, req.ip, (req.headers['user-agent'] || '').slice(0, 255), SESSION_H]);
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: cfg.prod, maxAge: SESSION_H * 3600 * 1000, path: '/' });
  return csrf;
}
async function encerrarSessao(req, res) {
  const t = req.cookies && req.cookies[COOKIE];
  if (t) await db.query('DELETE FROM ucp_sessions WHERE token_hash=?', [sha(t)]);
  res.clearCookie(COOKIE, { path: '/' });
}

// Resolve cargo/permissoes: o admin do jogo (arquivo de status) vira cargo no site automaticamente.
async function resolverStaff(nick) {
  const account = await db.one('SELECT discord_id, discord_roles FROM ucp_contas WHERE nick=?', [nick]);
  const discordId = account && account.discord_id ? String(account.discord_id) : '';
  if (discordId && cfg.discord.founderId && discordId === String(cfg.discord.founderId))
    return { cargo: 'Fundador', permissoes: roles.PERMISSOES.slice(), discordId };

  const ov = await db.one('SELECT cargo, extras, bloqueado FROM ucp_permissoes WHERE nick=?', [nick]);
  if (ov && ov.bloqueado) return { cargo: null, permissoes: [], discordId };
  let discordRoleCargo = null;
  if (account && account.discord_roles) {
    let ids = []; try { ids = JSON.parse(account.discord_roles) || []; } catch (_) { ids = []; }
    const priority = [
      ['Fundador', 'Fundador'], ['Dono', 'Dono'], ['ViceFundador', 'Vice-Fundador'], ['Diretor', 'Diretor'],
      ['Subdiretor', 'Subdiretor'], ['Gerente', 'Gerente'], ['AdministradorGeral', 'Administrador-Geral'],
      ['AdministradorMaster', 'Administrador Master'], ['Administrador', 'Administrador'], ['Coordenador', 'Coordenador'],
      ['Supervisor', 'Supervisor'], ['Moderador', 'Moderador'], ['Ajudante', 'Ajudante'], ['Suporte', 'Suporte']
    ];
    for (const [key, label] of priority) {
      const roleId = cfg.discord.roles[key];
      if (roleId && ids.includes(String(roleId))) { discordRoleCargo = label; break; }
    }
  }
  const cargo = discordRoleCargo || null;
  if (!cargo) return { cargo: null, permissoes: [], discordId };
  const row = await db.one('SELECT permissoes FROM ucp_cargos WHERE cargo=?', [cargo]);
  let perms = [];
  try { perms = row ? JSON.parse(row.permissoes) : (roles.PADRAO[cargo] || []); } catch (e) { perms = roles.PADRAO[cargo] || []; }
  if (ov && ov.extras) { try { perms = perms.concat(JSON.parse(ov.extras)); } catch (e) { /* ignora */ } }
  return { cargo, permissoes: Array.from(new Set(perms)), discordId };
}

async function carregarSessao(req, res, next) {
  req.user = null;
  const t = req.cookies && req.cookies[COOKIE];
  if (!t) return next();
  try {
    const s = await db.one('SELECT nick, csrf FROM ucp_sessions WHERE token_hash=? AND expira_em > NOW()', [sha(t)]);
    if (s) {
      const profile = await db.one('SELECT discord_id, discord_username, discord_avatar FROM ucp_contas WHERE nick=?', [s.nick]);
      if (!profile || !profile.discord_id) { await db.query('DELETE FROM ucp_sessions WHERE token_hash=?', [sha(t)]); res.clearCookie(COOKIE, { path: '/' }); return next(); }
      const member = await verificarMembroDiscord(profile.discord_id);
      if (member.missing) { await db.query('DELETE FROM ucp_sessions WHERE token_hash=?', [sha(t)]); res.clearCookie(COOKIE, { path: '/' }); return next(); }
      await db.query('UPDATE ucp_contas SET discord_roles=? WHERE nick=?', [JSON.stringify(member.roles), s.nick]);
      const staff = await resolverStaff(s.nick);
      req.user = { nick: s.nick, csrf: s.csrf, cargo: staff.cargo, permissoes: staff.permissoes, discordId: profile.discord_id, discordUsername: profile.discord_username, discordAvatar: profile.discord_avatar };
    }
  } catch (e) { return next(e); }
  next();
}
const exigirLogin = (req, res, next) => req.user ? next() : res.status(401).json({ erro: 'Voce precisa entrar no UCP.' });
const exigirPermissao = (perm) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ erro: 'Voce precisa entrar no UCP.' });
  if (!req.user.permissoes.includes(perm)) return res.status(403).json({ erro: 'Sem permissao para esta acao.' });
  next();
};
const exigirStaff = (req, res, next) => {
  if (!req.user) return res.status(401).json({ erro: 'Voce precisa entrar no UCP.' });
  if (!req.user.cargo) return res.status(403).json({ erro: 'Area restrita a equipe.' });
  next();
};
module.exports = { criarSessao, encerrarSessao, carregarSessao, exigirLogin, exigirPermissao, exigirStaff, COOKIE };
