const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { cfg, validate } = require('./config/env');
const db = require('./config/db');
const bridge = require('./services/bridge');
const pagamentos = require('./services/pagamentos');
const { carregarSessao } = require('./middleware/auth');
const csrf = require('./middleware/csrf');

validate();
const app = express();
app.set('trust proxy', 1); // atras de nginx/cloudflare; ajuste se nao usar proxy
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", 'https://fonts.googleapis.com'],
    fontSrc: ["'self'", 'https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"] } }
}));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 240, standardHeaders: true, legacyHeaders: false }));
app.use('/api', carregarSessao, csrf);
app.get('/health', (req, res) => res.status(200).json({ ok: true }));

app.use('/api/public', require('./routes/public'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/player', require('./routes/player'));
app.use('/api/tickets', require('./routes/tickets'));
app.use('/api/denuncias', require('./routes/denuncias'));
app.use('/api/arquivos', require('./routes/arquivos'));
app.use('/api/loja', require('./routes/shop'));
app.use('/api/webhooks', require('./routes/webhooks'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', (req, res) => res.status(404).json({ erro: 'Rota nao encontrada.' }));

app.use(express.static(path.resolve(__dirname, '../frontend'), { extensions: ['html'], maxAge: cfg.prod ? '1h' : 0 }));

// erros nunca vazam detalhes internos para o navegador
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err && /Somente imagens|File too large|Unexpected field/.test(err.message || '')) return res.status(400).json({ erro: err.message.includes('large') ? 'Arquivo maior que 5MB.' : err.message });
  console.error('[erro]', req.method, req.originalUrl, err && err.message);
  res.status(500).json({ erro: 'Erro interno. Tente novamente.' });
});

app.listen(cfg.port, () => console.log(`BPF UCP rodando na porta ${cfg.port}`));

// tarefas periodicas: confirmacoes de entrega, limpeza de codigos e sessoes expiradas
setInterval(() => pagamentos.sincronizarConfirmacoes().catch((e) => console.error('[sync]', e.message)), 15 * 1000);
setInterval(() => {
  bridge.limparCodigosExpirados();
  db.query('DELETE FROM ucp_sessions WHERE expira_em < NOW()').catch(() => {});
  db.query('DELETE FROM ucp_discord_pending WHERE expira_em < NOW()').catch(() => {});
  db.query('DELETE FROM ucp_tentativas WHERE criado_em < DATE_SUB(NOW(), INTERVAL 1 DAY)').catch(() => {});
  db.query("UPDATE ucp_compras SET status='expirada' WHERE status='pendente' AND criado_em < DATE_SUB(NOW(), INTERVAL 2 DAY)").catch(() => {});
}, 5 * 60 * 1000);
