# BPF UCP — Brasil Play Fortal RPG

Projeto original preservado com autenticação Discord + cadastro de Nick e senha do UCP.

## Como funciona o novo acesso
1. O jogador clica em **Continuar com Discord**.
2. O backend autentica via OAuth2 e verifica a presença no servidor usando o bot existente.
3. No primeiro acesso, o jogador cria Nick, senha e confirmação. O Discord fica vinculado de forma única à conta.
4. Nos próximos acessos, o Discord identifica a conta automaticamente. O login Nick/senha também permanece disponível.
5. Os cargos são lidos da associação do membro ao servidor e comparados com os IDs configurados no backend. A conta definida em `FOUNDER_DISCORD_ID` recebe o cargo Fundador e todas as permissões.

## Publicação: Netlify + backend + MySQL
**Não é possível hospedar este projeto completo somente no Netlify:** o Netlify publica o frontend estático, mas este projeto usa Express, sessões persistentes, MySQL e integração opcional com arquivos do SA-MP. O backend precisa ficar em um serviço Node (Render/Railway) e o banco em MySQL gerenciado.

1. Crie um banco MySQL gerenciado e execute `database/schema.sql`.
2. Para banco existente, faça backup e execute `database/migrations/001-discord-login.sql` uma única vez.
3. Publique o backend Node usando `render.yaml` ou configure `npm install` / `npm start` em outro host. Preencha todas as variáveis de `.env.example`.
4. Publique primeiro o frontend no Netlify e configure no Discord Developer Portal a OAuth2 Redirect URI exatamente como `https://SEU-SITE.netlify.app/api/auth/discord/callback` (a chamada será encaminhada pelo proxy do Netlify ao backend).
5. Adicione o bot existente ao servidor. Configure `DISCORD_BOT_TOKEN`, `DISCORD_GUILD_ID`, IDs dos cargos e `FOUNDER_DISCORD_ID`.
6. No `netlify.toml`, substitua `https://SEU-BACKEND.onrender.com` pela URL real do backend em `to`. Publique a pasta `frontend` no Netlify (ou conecte o repositório).
7. Configure `PUBLIC_URL` com a URL pública do backend e `DISCORD_REDIRECT_URI` com a URL do site Netlify mais `/api/auth/discord/callback`. Para cookies e OAuth, use HTTPS.

## IDs dos cargos
Ative o Modo Desenvolvedor no Discord e copie o ID de cada cargo. Preencha as variáveis `ROLE_*_ID`. O sistema reconhece cargos por ID, não por nome. O ID do Fundador deve ser o ID numérico da conta Discord, não o nome de usuário.

## Integração SA-MP opcional
O cadastro/login Discord funciona sem `SAMP_SCRIPTFILES`. Recursos que dependem da GameMode (status ao vivo, consulta de personagens e entrega automática de VIP/moedas) exigem que o backend tenha acesso persistente à pasta `scriptfiles/UCP` e que a GameMode esteja preparada conforme `docs/GAMEMODE.md`. Se não configurar isso, essas funções não estarão disponíveis; não são simuladas.

## Segurança
Nunca publique `.env`, Bot Token ou Client Secret. Use credenciais somente nas variáveis de ambiente do backend. Configure HTTPS e restrinja acesso ao painel. Faça backup do MySQL antes da migração.

## Verificação local
`npm install` → `npm run db:install` (banco vazio) → configure `.env` → `npm start`. O backend exige MySQL e credenciais Discord em produção.
