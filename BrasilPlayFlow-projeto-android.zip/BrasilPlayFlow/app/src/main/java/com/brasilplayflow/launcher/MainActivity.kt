package com.brasilplayflow.launcher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

// ====== TROQUE AQUI ======
const val OFFICIAL_NAME = "BRASIL PLAY FLOW"
const val OFFICIAL_IP = "SEU.IP.AQUI:7777"          // seu IP oficial
const val GAME_PACKAGE = "com.rockstargames.gtasa"  // pacote do cliente SA-MP instalado
// =========================
val Bg = Color(0xFF0B0F0C); val Card = Color(0xFF151A16)
val Green = Color(0xFF14B85A); val Yellow = Color(0xFFFFD21F)

class Store(c: Context) {
    val p = c.getSharedPreferences("bpf", 0)
    fun s(k: String, d: String) = p.getString(k, d) ?: d
    fun put(k: String, v: String) = p.edit().putString(k, v).apply()
    fun b(k: String, d: Boolean) = p.getBoolean(k, d)
    fun putB(k: String, v: Boolean) = p.edit().putBoolean(k, v).apply()
    fun favs() = s("favs", "").split("\n").filter { it.contains("|") }
    fun setFavs(l: List<String>) = put("favs", l.joinToString("\n"))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App(this) } }
}

fun play(c: Context, st: Store, server: String, nick: String) {
    val h = server.substringBefore(":"); val pt = server.substringAfter(":", "7777")
    val keys = listOf("hud", "autoaim", "gps", "voice", "killfeed", "kbd")
    val cfg = "nick=$nick\nip=$h\nport=$pt\nfps=${st.s("fps", "60")}\n" +
        keys.joinToString("\n") { "$it=${st.b(it, it in listOf("hud", "gps"))}" }
    File(c.filesDir, "bpf_settings.cfg").writeText(cfg)
    val i = Intent(Intent.ACTION_VIEW, Uri.parse("samp://$h:$pt")).apply {
        putExtra("nick", nick); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
    try { c.startActivity(i) } catch (e: Exception) {
        c.packageManager.getLaunchIntentForPackage(GAME_PACKAGE)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(it) } }
}

@Composable fun Box2(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(16.dp)).padding(16.dp), content = content)

@Composable fun App(ctx: Context) {
    val st = remember { Store(ctx) }
    var tab by remember { mutableStateOf(0) }
    var server by remember { mutableStateOf(st.s("server", OFFICIAL_IP)) }
    var nick by remember { mutableStateOf(st.s("nick", "")) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Card)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("Início", "Servidores", "Notícias", "Config.").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(listOf("🏠", "🗄", "📰", "⚙")[i]) }, label = { Text(t) }) } } }) { p ->
            Column(Modifier.padding(p).fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (tab) {
                    0 -> Home(ctx, st, server, nick, { nick = it; st.put("nick", it) }) { tab = 1 }
                    1 -> Servers(st, server) { server = it; st.put("server", it); tab = 0 }
                    2 -> News()
                    else -> Settings(ctx, st)
                }
            }
        }
    }
}

@Composable fun Home(ctx: Context, st: Store, server: String, nick: String, onNick: (String) -> Unit, change: () -> Unit) {
    Text(OFFICIAL_NAME, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Yellow)
    Text("SA-MP Mobile", color = Color.Gray)
    Box2 {
        Text("Servidor selecionado", color = Color.Gray)
        Text(server, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = change) { Text("Trocar servidor") }
    }
    Box2 {
        Text("Nick do jogador", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(nick, onNick, singleLine = true, modifier = Modifier.fillMaxWidth(),
            supportingText = { Text("Ex: Nome_Sobrenome") })
        Button(onClick = { play(ctx, st, server, nick) }, enabled = nick.matches(Regex("[A-Za-z0-9_\\[\\]]{3,24}")),
            modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp)) { Text("▶  Jogar", fontSize = 18.sp) }
        Text("Launcher 1.0.0", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable fun Servers(st: Store, current: String, pick: (String) -> Unit) {
    var sub by remember { mutableStateOf(0) }
    var favs by remember { mutableStateOf(st.favs()) }
    var dlg by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Servidores", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (sub == 1) Button(onClick = { dlg = true }) { Text("Adicionar") }
    }
    TabRow(selectedTabIndex = sub, containerColor = Card) {
        listOf("Oficiais", "Favoritos").forEachIndexed { i, t -> Tab(sub == i, { sub = i }, text = { Text(t) }) } }
    val list = if (sub == 0) listOf("$OFFICIAL_NAME|$OFFICIAL_IP") else favs
    list.forEach { f ->
        Box2 {
            Text(f.substringBefore("|"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(f.substringAfter("|"), color = Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pick(f.substringAfter("|")) }) { Text(if (f.substringAfter("|") == current) "Selecionado" else "Selecionar") }
                if (sub == 1) TextButton(onClick = { favs = favs - f; st.setFavs(favs) }) { Text("Remover") }
            }
        }
    }
    if (sub == 1 && favs.isEmpty()) Text("Nenhum favorito. Toque em Adicionar.", color = Color.Gray)
    if (dlg) {
        var n by remember { mutableStateOf("") }; var ip by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { dlg = false }, title = { Text("Adicionar servidor") },
            text = { Column { OutlinedTextField(n, { n = it }, label = { Text("Nome") }, singleLine = true)
                OutlinedTextField(ip, { ip = it }, label = { Text("IP:porta") }, singleLine = true) } },
            confirmButton = { TextButton(onClick = {
                if (ip.isNotBlank()) { favs = favs + "${n.ifBlank { ip }}|${if (":" in ip) ip else "$ip:7777"}"; st.setFavs(favs) }
                dlg = false }) { Text("Salvar") } },
            dismissButton = { TextButton(onClick = { dlg = false }) { Text("Cancelar") } })
    }
}

@Composable fun News() {
    Text("Notícias", fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Box2 { Text("Bem-vindo ao $OFFICIAL_NAME", fontWeight = FontWeight.Bold); Text("Edite as notícias no arquivo MainActivity.kt.", color = Color.Gray) }
}

@Composable fun SwitchRow(st: Store, key: String, title: String, desc: String, def: Boolean = false) {
    var v by remember { mutableStateOf(st.b(key, def)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontSize = 16.sp); Text(desc, color = Color.Gray, fontSize = 12.sp) }
        Switch(v, { v = it; st.putB(key, it) })
    }
}

@Composable fun Settings(ctx: Context, st: Store) {
    var sub by remember { mutableStateOf(0) }
    val tabs = listOf("Jogo", "Atualizações", "Chat", "Notificações", "Permissões", "Mods e dados")
    Text("Configurações", fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Text("As alterações serão aplicadas ao iniciar o jogo.", color = Color.Gray, fontSize = 12.sp)
    ScrollableTabRow(selectedTabIndex = sub, containerColor = Card, edgePadding = 0.dp) {
        tabs.forEachIndexed { i, t -> Tab(sub == i, { sub = i }, text = { Text(t) }) } }
    when (sub) {
        0 -> Box2 {
            SwitchRow(st, "hud", "HUD Mobile", "Interface de toque do jogo.", true)
            SwitchRow(st, "autoaim", "Mira automática", "Usa a trava de alvo nativa do GTA SA, se o cliente suportar.")
            SwitchRow(st, "gps", "GPS", "Indicador até checkpoints e destinos.", true)
            SwitchRow(st, "voice", "Chat de voz", "Ativa o chat de voz.")
            SwitchRow(st, "killfeed", "Mostrar kill feed", "Exibe eliminações no canto da tela.")
            SwitchRow(st, "kbd", "Teclado do Android", "Desativado: teclado interno.")
            var fps by remember { mutableStateOf(st.s("fps", "60")) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Limite de FPS", Modifier.weight(1f))
                listOf("30", "60", "90", "120").forEach { o ->
                    TextButton(onClick = { fps = o; st.put("fps", o) }) { Text(o, color = if (fps == o) Yellow else Color.Gray) } }
            }
        }
        4 -> Box2 {
            val launcher = rememberLauncher()
            Text("Permissões do aplicativo", fontWeight = FontWeight.Bold)
            Text("Microfone (necessário para o chat de voz)", color = Color.Gray)
            OutlinedButton(onClick = { launcher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Permitir microfone") }
        }
        else -> Box2 { Text(tabs[sub], fontWeight = FontWeight.Bold); Text("Em breve.", color = Color.Gray) }
    }
}

@Composable fun rememberLauncher() =
    androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
